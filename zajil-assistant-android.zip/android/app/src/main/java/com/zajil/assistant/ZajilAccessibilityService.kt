package com.zajil.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * ZajilAccessibilityService:
 * Implements real Android screen click automation via AccessibilityService.
 * Can click anywhere on screen coordinates or find and click app icons by name.
 */
class ZajilAccessibilityService : AccessibilityService() {

    companion object {
        var instance: ZajilAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Toast.makeText(this, "تم تفعيل خدمة إمكانية الوصول لزاجل بنجاح!", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Monitors screen state and open applications
    }

    override fun onInterrupt() {
        instance = null
    }

    /**
     * Dispatches a real Android tap gesture at exact screen coordinates (x, y).
     * Supported on Android 7.0 (API 24) and higher!
     */
    fun clickAtCoordinates(x: Float, y: Float, onComplete: (() -> Unit)? = null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val clickPath = Path().apply {
                moveTo(x, y)
            }
            val stroke = GestureDescription.StrokeDescription(clickPath, 0, 80)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                    onComplete?.invoke()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                    onComplete?.invoke()
                }
            }, null)
        } else {
            onComplete?.invoke()
        }
    }

    /**
     * Searches the active Android window for a node containing the specified text
     * (e.g. "الكاميرا", "الحاسبة", "الموسيقى") and clicks it!
     */
    fun findAndClickAppByName(appName: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(appName)
        if (!nodes.isNullOrEmpty()) {
            for (node in nodes) {
                if (node.isClickable) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable) {
                        parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return true
                    }
                    parent = parent.parent
                }
            }
        }
        return false
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
