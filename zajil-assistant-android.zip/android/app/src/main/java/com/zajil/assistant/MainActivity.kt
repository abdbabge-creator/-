package com.zajil.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

/**
 * MainActivity: Coordinates native Android Overlay permission (SYSTEM_ALERT_WINDOW),
 * Accessibility Service permissions, and hosts the high-performance UI inside an
 * optimized WebView with two-way native bridging.
 */
class MainActivity : Activity() {

    private val OVERLAY_PERMISSION_REQ_CODE = 1201
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupWebView()
        checkAndRequestPermissions()
    }

    private fun setupWebView() {
        webView = findViewById(R.id.webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()

        // Attach JavaScript Bridge
        webView.addJavascriptInterface(AndroidBridge(this, this), "AndroidBridge")

        // In production build: load local asset or server endpoint
        webView.loadUrl("file:///android_asset/dist/index.html")
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    fun checkAndRequestPermissions() {
        // 1. Check SYSTEM_ALERT_WINDOW (Draw over other apps)
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE)
            Toast.makeText(this, "يرجى منح إذن الظهور فوق التطبيقات لتشغيل الطائر العائم", Toast.LENGTH_LONG).show()
        } else {
            startFloatingService()
        }

        // 2. Check Accessibility Service
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, "لتنفيذ النقرات الحقيقية وفتح التطبيقات، يرجى تفعيل خدمة إمكانية الوصول لزاجل", Toast.LENGTH_LONG).show()
        }
    }

    fun startFloatingService() {
        if (Settings.canDrawOverlays(this)) {
            val serviceIntent = Intent(this, FloatingOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        }
    }

    fun stopFloatingService() {
        val serviceIntent = Intent(this, FloatingOverlayService::class.java)
        stopService(serviceIntent)
    }

    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
    }

    fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        for (service in enabledServices) {
            if (service.resolveInfo.serviceInfo.packageName == packageName &&
                service.resolveInfo.serviceInfo.name.contains("ZajilAccessibilityService")
            ) {
                return true
            }
        }
        return false
    }

    private fun updatePermissionStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val accessibilityOk = isAccessibilityServiceEnabled()
        if (overlayOk && accessibilityOk) {
            startFloatingService()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OVERLAY_PERMISSION_REQ_CODE) {
            if (Settings.canDrawOverlays(this)) {
                startFloatingService()
                Toast.makeText(this, "تم تفعيل إذن الظهور فوق التطبيقات بنجاح!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
