package com.zajil.assistant

import android.content.Context
import android.webkit.JavascriptInterface
import android.widget.Toast

/**
 * JavaScriptInterface Bridge: Connects the React/TypeScript frontend with
 * native Android hardware APIs, Accessibility Service, and WindowManager Overlays.
 */
class AndroidBridge(private val context: Context, private val activity: MainActivity) {

    @JavascriptInterface
    fun requestOverlayPermission() {
        activity.runOnUiThread {
            activity.checkAndRequestPermissions()
        }
    }

    @JavascriptInterface
    fun openAccessibilitySettings() {
        activity.runOnUiThread {
            activity.openAccessibilitySettings()
        }
    }

    @JavascriptInterface
    fun flyToAndClick(x: Float, y: Float) {
        activity.runOnUiThread {
            FloatingOverlayService.instance?.flyToTargetAndClick(x.toInt(), y.toInt()) {
                // Click executed via AccessibilityService
            }
        }
    }

    @JavascriptInterface
    fun isOverlayEnabled(): Boolean {
        return android.provider.Settings.canDrawOverlays(context)
    }

    @JavascriptInterface
    fun isAccessibilityEnabled(): Boolean {
        return activity.isAccessibilityServiceEnabled()
    }

    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }
}
