export type AppId =
  | 'camera'
  | 'calculator'
  | 'weather'
  | 'clock'
  | 'music'
  | 'notes'
  | 'phone'
  | 'messages'
  | 'settings'
  | 'maps'
  | 'gallery'
  | 'customizer'
  | 'android_service';

export type BirdEmotion =
  | 'idle'
  | 'listening'
  | 'thinking'
  | 'speaking'
  | 'happy'
  | 'cheering'
  | 'surprised'
  | 'sleepy'
  | 'proud'
  | 'playful'
  | 'curious'
  | 'flying'
  | 'pecking';

export type CharacterId =
  | 'male_bird'
  | 'female_bird'
  | 'smart_robot'
  | 'cartoon_human';

export type VoiceGender = 'male' | 'female';

export interface CharacterProfile {
  id: CharacterId;
  name: string;
  title: string;
  gender: VoiceGender;
  description: string;
  avatarBg: string;
  badgeColor: string;
  defaultPitch: number;
  defaultRate: number;
  greeting: string;
}

export interface AndroidSystemState {
  floatingOverlayEnabled: boolean;
  overlayPermissionGranted: boolean;
  accessibilityServiceEnabled: boolean;
  flightAnimationEnabled: boolean;
  snapToEdges: boolean;
}

export interface PermissionsState {
  microphone: boolean;
  camera: boolean;
  geolocation: boolean;
  notifications: boolean;
}

export interface AssistantAction {
  type:
    | 'open_app'
    | 'set_timer'
    | 'play_music'
    | 'pause_music'
    | 'weather_query'
    | 'calculate'
    | 'add_note'
    | 'make_call'
    | 'send_message'
    | 'toggle_flashlight'
    | 'request_permission'
    | 'close_app'
    | 'none';
  appId?: AppId;
  payload?: {
    query?: string;
    city?: string;
    durationSeconds?: number;
    noteText?: string;
    calcExpression?: string;
    calcResult?: string;
    contactName?: string;
    phoneNumber?: string;
    messageText?: string;
    permissionName?: keyof PermissionsState;
  };
  requiresPermission?: keyof PermissionsState;
}

export interface ProcessResponse {
  spokenReply: string;
  birdEmotion: BirdEmotion;
  action?: AssistantAction;
}

export interface NoteItem {
  id: string;
  text: string;
  date: string;
}

export interface ContactItem {
  id: string;
  name: string;
  phone: string;
  avatarColor: string;
}

export interface WeatherData {
  city: string;
  temp: number;
  condition: string;
  high: number;
  low: number;
  humidity: number;
  windSpeed: number;
  icon: 'sunny' | 'cloudy' | 'rainy' | 'partlyCloudy';
}
