// Audio Synthesizer, Character Sound Effects and Voice Manager
import { VoiceGender } from '../types';

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// Robot cyber bleeps
export function playRobotBeep(type: 'cheerful' | 'question' | 'greeting' | 'giggle' | 'success' = 'cheerful') {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    if (type === 'question') {
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
    } else if (type === 'success') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.08);
      osc.frequency.setValueAtTime(1046.5, now + 0.16);
    } else {
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.linearRampToValueAtTime(1200, now + 0.08);
      osc.frequency.linearRampToValueAtTime(800, now + 0.15);
    }

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.2);
  } catch (e) {}
}

// Human cartoon bright friendly chime
export function playHumanChime(type: 'cheerful' | 'question' | 'greeting' | 'giggle' | 'success' = 'cheerful') {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const notes = type === 'success' ? [523.25, 659.25, 783.99, 1046.5] : [440, 554.37, 659.25];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const start = now + idx * 0.06;
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.09, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.22);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.22);
    });
  } catch (e) {}
}

// Play cute bird chirps
export function playChirp(type: 'cheerful' | 'question' | 'greeting' | 'giggle' | 'success' = 'cheerful') {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    if (type === 'giggle') {
      for (let i = 0; i < 4; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        const start = now + i * 0.08;
        osc.frequency.setValueAtTime(1400 + i * 150, start);
        osc.frequency.exponentialRampToValueAtTime(1900 + i * 100, start + 0.05);

        gain.gain.setValueAtTime(0.12, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.07);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + 0.07);
      }
      return;
    }

    if (type === 'question') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(1600, now + 0.2);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
      return;
    }

    if (type === 'success') {
      const freqs = [523.25, 659.25, 783.99, 1046.5];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        const start = now + idx * 0.06;
        osc.frequency.setValueAtTime(freq, start);
        gain.gain.setValueAtTime(0.1, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + 0.18);
      });
      return;
    }

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, now);
    osc.frequency.linearRampToValueAtTime(2200, now + 0.08);
    osc.frequency.linearRampToValueAtTime(1500, now + 0.15);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.18);
  } catch (e) {
    console.debug('Chirp audio error:', e);
  }
}

// Camera shutter sound effect
export function playCameraShutter() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.06);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.08);
  } catch (e) {}
}

// Timer alarm chime
export function playAlarmChime() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    for (let i = 0; i < 3; i++) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      const start = now + i * 0.15;
      osc.frequency.setValueAtTime(880, start);
      osc.frequency.setValueAtTime(1760, start + 0.07);

      gain.gain.setValueAtTime(0.18, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.13);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.13);
    }
  } catch (e) {}
}

let currentUtterance: SpeechSynthesisUtterance | null = null;
let currentAudioElement: HTMLAudioElement | null = null;
let beakInterval: any = null;

// Find best Arabic voice available in the browser matching gender preference
export function getArabicVoice(gender: VoiceGender = 'male'): SpeechSynthesisVoice | null {
  if (!('speechSynthesis' in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  const arVoices = voices.filter(
    (v) => v.lang.startsWith('ar') || v.name.includes('Arabic') || v.lang.includes('AR')
  );

  if (arVoices.length === 0) return null;

  if (gender === 'female') {
    const femaleMatch = arVoices.find(
      (v) =>
        v.name.includes('Laila') ||
        v.name.includes('Salma') ||
        v.name.includes('Zariyah') ||
        v.name.includes('Female') ||
        v.name.includes('Hoda') ||
        v.name.includes('Zeina')
    );
    if (femaleMatch) return femaleMatch;
  } else {
    const maleMatch = arVoices.find(
      (v) =>
        v.name.includes('Maged') ||
        v.name.includes('Tariq') ||
        v.name.includes('Naayf') ||
        v.name.includes('Male') ||
        v.name.includes('Shakir')
    );
    if (maleMatch) return maleMatch;
  }

  // Fallback to highest quality Arabic voice
  const premium = arVoices.find((v) => v.name.includes('Google') || v.name.includes('Natural'));
  return premium || arVoices[0];
}

export interface SpeakOptions {
  text: string;
  audioBase64?: string;
  gender?: VoiceGender;
  voicePitch?: number;
  voiceRate?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onBeakTick?: (openState: boolean) => void;
}

// Stop any currently playing speech or audio
export function stopSpeaking() {
  if (beakInterval) {
    clearInterval(beakInterval);
    beakInterval = null;
  }
  if (currentAudioElement) {
    currentAudioElement.pause();
    currentAudioElement = null;
  }
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
  currentUtterance = null;
}

// Speak the Arabic response (Pure voice output, synchronized with mouth/beak flap)
export async function speakArabicText({
  text,
  audioBase64,
  gender = 'male',
  voicePitch,
  voiceRate = 1.0,
  onStart,
  onEnd,
  onBeakTick,
}: SpeakOptions) {
  stopSpeaking();

  const startBeakAnimation = () => {
    let isOpen = false;
    beakInterval = setInterval(() => {
      isOpen = !isOpen;
      onBeakTick?.(isOpen);
    }, 110);
  };

  const stopBeakAnimation = () => {
    if (beakInterval) {
      clearInterval(beakInterval);
      beakInterval = null;
    }
    onBeakTick?.(false);
  };

  // If we have Gemini generated audio base64, play it
  if (audioBase64) {
    try {
      const audio = new Audio(`data:audio/wav;base64,${audioBase64}`);
      currentAudioElement = audio;

      audio.onplay = () => {
        onStart?.();
        startBeakAnimation();
      };

      audio.onended = () => {
        stopBeakAnimation();
        onEnd?.();
      };

      audio.onerror = () => {
        stopBeakAnimation();
        fallbackToBrowserSpeech();
      };

      await audio.play();
      return;
    } catch (e) {
      console.warn('Gemini audio playback error, falling back to Web Speech:', e);
    }
  }

  // Browser SpeechSynthesis Fallback
  function fallbackToBrowserSpeech() {
    if (!('speechSynthesis' in window)) {
      onStart?.();
      startBeakAnimation();
      setTimeout(() => {
        stopBeakAnimation();
        onEnd?.();
      }, Math.max(1500, text.length * 80));
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    currentUtterance = utterance;

    const voice = getArabicVoice(gender);
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang;
    } else {
      utterance.lang = 'ar-SA';
    }

    // Default pitch tailored to gender if not explicitly provided
    const targetPitch =
      voicePitch !== undefined
        ? voicePitch
        : gender === 'female'
        ? 1.2
        : 1.0;

    utterance.pitch = targetPitch;
    utterance.rate = voiceRate;

    utterance.onstart = () => {
      onStart?.();
      startBeakAnimation();
    };

    utterance.onend = () => {
      stopBeakAnimation();
      onEnd?.();
      currentUtterance = null;
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis error:', e);
      stopBeakAnimation();
      onEnd?.();
      currentUtterance = null;
    };

    window.speechSynthesis.speak(utterance);
  }

  fallbackToBrowserSpeech();
}
