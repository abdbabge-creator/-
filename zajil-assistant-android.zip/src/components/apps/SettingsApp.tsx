import React from 'react';
import { Settings, Mic, Camera, MapPin, Bell, Wand2, Sparkles, CheckCircle2, XCircle, ArrowLeft } from 'lucide-react';
import { PermissionsState, CharacterId, VoiceGender } from '../../types';
import { CHARACTER_PROFILES } from '../characters/characterProfiles';

interface SettingsAppProps {
  permissions: PermissionsState;
  onTogglePermission: (name: keyof PermissionsState) => void;
  voicePitch: number;
  setVoicePitch: (pitch: number) => void;
  voiceRate: number;
  setVoiceRate: (rate: number) => void;
  wallpaper: string;
  setWallpaper: (wp: string) => void;
  selectedCharacter: CharacterId;
  voiceGender: VoiceGender;
  onSelectVoiceGender: (gender: VoiceGender) => void;
  onOpenCharacterCustomizer: () => void;
}

const WALLPAPERS = [
  { id: 'mesh', name: 'الكون الليلي', style: 'bg-linear-to-br from-indigo-950 via-slate-900 to-purple-950' },
  { id: 'desert', name: 'كثبان الغروب', style: 'bg-linear-to-br from-amber-950 via-rose-950 to-slate-950' },
  { id: 'ocean', name: 'المحيط الأزرق', style: 'bg-linear-to-br from-cyan-950 via-blue-950 to-slate-950' },
  { id: 'emerald', name: 'الواحة الخضراء', style: 'bg-linear-to-br from-emerald-950 via-teal-950 to-slate-950' },
];

export const SettingsApp: React.FC<SettingsAppProps> = ({
  permissions,
  onTogglePermission,
  voicePitch,
  setVoicePitch,
  voiceRate,
  setVoiceRate,
  wallpaper,
  setWallpaper,
  selectedCharacter,
  voiceGender,
  onSelectVoiceGender,
  onOpenCharacterCustomizer,
}) => {
  const currentProfile = CHARACTER_PROFILES[selectedCharacter] || CHARACTER_PROFILES.male_bird;

  return (
    <div className="h-full bg-slate-950 text-white flex flex-col p-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800">
        <div className="w-8 h-8 rounded-xl bg-slate-800 text-slate-200 flex items-center justify-center">
          <Settings className="w-4 h-4" />
        </div>
        <div>
          <h2 className="text-lg font-bold">الإعدادات والصلاحيات</h2>
          <p className="text-[11px] text-slate-400">إدارة مظهر وصوت وصلاحيات المساعد</p>
        </div>
      </div>

      {/* Hero Card: Character Customization Launcher */}
      <div
        onClick={onOpenCharacterCustomizer}
        className="mb-5 p-3.5 rounded-3xl bg-linear-to-r from-indigo-900/60 via-purple-900/50 to-slate-900 border border-purple-500/30 hover:border-purple-400/60 cursor-pointer active:scale-98 transition-all shadow-lg flex items-center justify-between group"
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-12 h-12 rounded-2xl ${currentProfile.avatarBg} text-white flex items-center justify-center text-2xl shadow-md group-hover:scale-105 transition-transform`}
          >
            {selectedCharacter === 'male_bird'
              ? '🐦'
              : selectedCharacter === 'female_bird'
              ? '🌸'
              : selectedCharacter === 'smart_robot'
              ? '🤖'
              : '🧑'}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-white">{currentProfile.name}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/30 text-purple-300 font-medium">
                {currentProfile.title}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mt-0.5">
              تغيير الشخصية (٤ شخصيات) ونوع الصوت
            </p>
          </div>
        </div>
        <div className="w-8 h-8 rounded-full bg-white/10 group-hover:bg-purple-500 text-white flex items-center justify-center transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </div>
      </div>

      {/* Voice Gender Selection */}
      <div className="mb-5">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
          نوع الصوت العربي
        </h3>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onSelectVoiceGender('male')}
            className={`p-2.5 rounded-xl border flex items-center justify-center gap-2 transition-all active:scale-95 ${
              voiceGender === 'male'
                ? 'bg-blue-600/20 border-blue-400 text-blue-300 font-bold shadow-md'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <span>👨</span>
            <span className="text-xs">صوت ذكر عربي</span>
          </button>
          <button
            onClick={() => onSelectVoiceGender('female')}
            className={`p-2.5 rounded-xl border flex items-center justify-center gap-2 transition-all active:scale-95 ${
              voiceGender === 'female'
                ? 'bg-pink-600/20 border-pink-400 text-pink-300 font-bold shadow-md'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <span>👩</span>
            <span className="text-xs">صوت أنثى عربي</span>
          </button>
        </div>
      </div>

      {/* Permissions Section */}
      <div className="mb-5">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
          صلاحيات الهاتف والمساعد
        </h3>
        <div className="space-y-2">
          {/* Microphone */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <Mic className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-100">الميكروفون</div>
                <div className="text-[10px] text-slate-400">للاستماع للأوامر الصوتية</div>
              </div>
            </div>
            <button
              onClick={() => onTogglePermission('microphone')}
              className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${
                permissions.microphone
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              {permissions.microphone ? (
                <>
                  <CheckCircle2 className="w-3 h-3" />
                  <span>ممنوح</span>
                </>
              ) : (
                <>
                  <XCircle className="w-3 h-3" />
                  <span>تفعيل</span>
                </>
              )}
            </button>
          </div>

          {/* Camera */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                <Camera className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-100">الكاميرا</div>
                <div className="text-[10px] text-slate-400">لفتح الكاميرا والتقاط الصور</div>
              </div>
            </div>
            <button
              onClick={() => onTogglePermission('camera')}
              className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${
                permissions.camera
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              {permissions.camera ? (
                <>
                  <CheckCircle2 className="w-3 h-3" />
                  <span>ممنوح</span>
                </>
              ) : (
                <>
                  <XCircle className="w-3 h-3" />
                  <span>تفعيل</span>
                </>
              )}
            </button>
          </div>

          {/* Location */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-100">الموقع الجغرافي</div>
                <div className="text-[10px] text-slate-400">لتحديد طقس منطقتك بدقة</div>
              </div>
            </div>
            <button
              onClick={() => onTogglePermission('geolocation')}
              className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${
                permissions.geolocation
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              {permissions.geolocation ? (
                <>
                  <CheckCircle2 className="w-3 h-3" />
                  <span>ممنوح</span>
                </>
              ) : (
                <>
                  <XCircle className="w-3 h-3" />
                  <span>تفعيل</span>
                </>
              )}
            </button>
          </div>

          {/* Notifications */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-100">التنبيهات</div>
                <div className="text-[10px] text-slate-400">لرنين المنبه والمؤقت</div>
              </div>
            </div>
            <button
              onClick={() => onTogglePermission('notifications')}
              className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${
                permissions.notifications
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              {permissions.notifications ? (
                <>
                  <CheckCircle2 className="w-3 h-3" />
                  <span>ممنوح</span>
                </>
              ) : (
                <>
                  <XCircle className="w-3 h-3" />
                  <span>تفعيل</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Voice Tuning Section */}
      <div className="mb-5">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
          نبرة الصوت وسرعة الكلام
        </h3>
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-300">طبقة الصوت (Pitch)</span>
              <span className="text-amber-400 font-mono">{voicePitch.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.5"
              step="0.05"
              value={voicePitch}
              onChange={(e) => setVoicePitch(parseFloat(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-300">سرعة النطق (Speed)</span>
              <span className="text-amber-400 font-mono">{voiceRate.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.3"
              step="0.05"
              value={voiceRate}
              onChange={(e) => setVoiceRate(parseFloat(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Wallpaper Switcher */}
      <div>
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
          خلفية شاشة الهاتف
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {WALLPAPERS.map((wp) => (
            <button
              key={wp.id}
              onClick={() => setWallpaper(wp.id)}
              className={`p-2.5 rounded-xl border text-right transition-all flex items-center justify-between ${
                wallpaper === wp.id
                  ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200 shadow-md'
                  : 'border-slate-800 bg-slate-900 text-slate-400 hover:border-slate-700'
              }`}
            >
              <span className="text-xs font-bold">{wp.name}</span>
              <div className={`w-3.5 h-3.5 rounded-full ${wp.style} border border-white/20`} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
