import React, { useState, useEffect } from 'react';
import { Phone, PhoneCall, PhoneOff, User, Delete } from 'lucide-react';
import { ContactItem } from '../../types';

interface PhoneAppProps {
  initialContactName?: string;
  initialPhoneNumber?: string;
}

const DEFAULT_CONTACTS: ContactItem[] = [
  { id: '1', name: 'ماما ❤️', phone: '0501234567', avatarColor: 'bg-rose-500' },
  { id: '2', name: 'بابا 🌟', phone: '0507654321', avatarColor: 'bg-blue-500' },
  { id: '3', name: 'أحمد', phone: '0559988776', avatarColor: 'bg-emerald-500' },
  { id: '4', name: 'فاطمة', phone: '0543322110', avatarColor: 'bg-purple-500' },
  { id: '5', name: 'سارة', phone: '0567788990', avatarColor: 'bg-amber-500' },
];

export const PhoneApp: React.FC<PhoneAppProps> = ({
  initialContactName,
  initialPhoneNumber,
}) => {
  const [tab, setTab] = useState<'keypad' | 'contacts'>('contacts');
  const [dialedNumber, setDialedNumber] = useState(initialPhoneNumber || '');
  const [callingState, setCallingState] = useState<{
    active: boolean;
    name: string;
    phone: string;
    seconds: number;
  } | null>(null);

  useEffect(() => {
    if (initialContactName || initialPhoneNumber) {
      const targetName = initialContactName || 'رقم هاتف';
      const targetPhone =
        initialPhoneNumber ||
        DEFAULT_CONTACTS.find((c) => c.name.includes(targetName))?.phone ||
        '0500000000';
      startCall(targetName, targetPhone);
    }
  }, [initialContactName, initialPhoneNumber]);

  // Call timer
  useEffect(() => {
    let interval: any = null;
    if (callingState?.active) {
      interval = setInterval(() => {
        setCallingState((prev) => (prev ? { ...prev, seconds: prev.seconds + 1 } : null));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callingState?.active]);

  const startCall = (name: string, phone: string) => {
    setCallingState({
      active: true,
      name,
      phone,
      seconds: 0,
    });
  };

  const endCall = () => {
    setCallingState(null);
  };

  const handleDigit = (digit: string) => {
    setDialedNumber((prev) => prev + digit);
  };

  // Active Simulated Call Screen
  if (callingState?.active) {
    const mins = Math.floor(callingState.seconds / 60);
    const secs = callingState.seconds % 60;
    const timeFormatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

    return (
      <div className="h-full bg-linear-to-b from-slate-900 via-indigo-950 to-slate-950 text-white flex flex-col justify-between p-8 text-center select-none">
        <div className="mt-8">
          <div className="w-24 h-24 rounded-full bg-linear-to-tr from-cyan-500 to-blue-600 mx-auto flex items-center justify-center text-3xl font-bold shadow-2xl mb-4 border-2 border-white/20">
            {callingState.name.slice(0, 1)}
          </div>
          <h2 className="text-2xl font-bold">{callingState.name}</h2>
          <p className="text-sm text-slate-400 mt-1 font-mono">{callingState.phone}</p>
          <div className="text-emerald-400 text-sm font-medium mt-3 flex items-center justify-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>متصل ({timeFormatted})</span>
          </div>
        </div>

        {/* Hangup Button */}
        <div className="mb-6 flex justify-center">
          <button
            onClick={endCall}
            className="w-18 h-18 rounded-full bg-rose-600 hover:bg-rose-500 active:scale-90 transition-all flex items-center justify-center shadow-xl shadow-rose-600/30 text-white"
          >
            <PhoneOff className="w-8 h-8" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-slate-950 text-white flex flex-col justify-between p-5 select-none">
      {/* Top Tabs */}
      <div className="flex bg-slate-900 p-1 rounded-2xl border border-slate-800 mb-3">
        <button
          onClick={() => setTab('contacts')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            tab === 'contacts' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400'
          }`}
        >
          <User className="w-4 h-4" />
          <span>جهات الاتصال</span>
        </button>
        <button
          onClick={() => setTab('keypad')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            tab === 'keypad' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400'
          }`}
        >
          <Phone className="w-4 h-4" />
          <span>لوحة الأرقام</span>
        </button>
      </div>

      {/* Main Tab Content */}
      {tab === 'contacts' ? (
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {DEFAULT_CONTACTS.map((c) => (
            <div
              key={c.id}
              onClick={() => startCall(c.name, c.phone)}
              className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-emerald-500/50 flex items-center justify-between cursor-pointer active:scale-98 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-11 h-11 rounded-full ${c.avatarColor} text-white flex items-center justify-center font-bold text-sm shadow-md`}
                >
                  {c.name.slice(0, 1)}
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
                    {c.name}
                  </div>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">{c.phone}</div>
                </div>
              </div>
              <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-white transition-all">
                <PhoneCall className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex-1 flex flex-col justify-end" dir="ltr">
          {/* Dialed Display */}
          <div className="text-center mb-4 h-12 flex items-center justify-center px-4">
            <span className="text-3xl font-mono tracking-wider font-light text-white truncate">
              {dialedNumber || ' '}
            </span>
          </div>

          {/* Keypad */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((d) => (
              <button
                key={d}
                onClick={() => handleDigit(d)}
                className="h-14 rounded-2xl bg-slate-900 hover:bg-slate-800 active:scale-90 text-xl font-medium text-slate-100 flex items-center justify-center border border-slate-800/80 transition-all"
              >
                {d}
              </button>
            ))}
          </div>

          {/* Call & Backspace Row */}
          <div className="flex items-center justify-center gap-6 mb-2">
            <div className="w-12 h-12" />
            <button
              onClick={() => startCall('رقم مباشر', dialedNumber || '0501234567')}
              className="w-16 h-16 rounded-full bg-emerald-600 hover:bg-emerald-500 active:scale-90 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 transition-all"
            >
              <Phone className="w-7 h-7" />
            </button>
            <button
              onClick={() => setDialedNumber((prev) => prev.slice(0, -1))}
              className="w-12 h-12 rounded-full text-slate-400 hover:text-white active:scale-90 flex items-center justify-center"
            >
              <Delete className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
