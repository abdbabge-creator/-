import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Volume2, Disc, Music } from 'lucide-react';

interface MusicAppProps {
  autoPlay?: boolean;
}

const TRACKS = [
  {
    id: 1,
    title: 'تغريد الصباح اللطيف',
    artist: 'زاجل والأصدقاء',
    album: 'ألحان الطبيعة الهادئة',
    color: 'from-amber-400 to-rose-400',
    bpm: 90,
    chords: [261.63, 329.63, 392.0, 523.25], // C major arpeggio
  },
  {
    id: 2,
    title: 'ألحان واحة النخيل',
    artist: 'نسائم عربية',
    album: 'رحلة استرخاء',
    color: 'from-teal-400 to-emerald-500',
    bpm: 80,
    chords: [220.0, 261.63, 329.63, 440.0], // A minor
  },
  {
    id: 3,
    title: 'أنغام شروق الشمس',
    artist: 'بلبل الصباح',
    album: 'طاقة إيجابية',
    color: 'from-cyan-400 to-blue-500',
    bpm: 100,
    chords: [349.23, 440.0, 523.25, 698.46], // F major
  },
];

export const MusicApp: React.FC<MusicAppProps> = ({ autoPlay = false }) => {
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(autoPlay);
  const [progress, setProgress] = useState(0);

  const synthIntervalRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const track = TRACKS[currentTrackIndex];

  // Synthesize musical ambient tones using Web Audio API
  useEffect(() => {
    if (isPlaying) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      let step = 0;
      synthIntervalRef.current = setInterval(() => {
        try {
          if (ctx.state === 'suspended') ctx.resume();

          const now = ctx.currentTime;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();

          const notes = track.chords;
          const noteFreq = notes[step % notes.length];
          step++;

          osc.type = 'sine';
          osc.frequency.setValueAtTime(noteFreq, now);

          gain.gain.setValueAtTime(0.08, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.4);

          setProgress((p) => (p >= 100 ? 0 : p + 1.2));
        } catch (e) {}
      }, 500);
    } else {
      if (synthIntervalRef.current) {
        clearInterval(synthIntervalRef.current);
      }
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {});
        audioContextRef.current = null;
      }
    }

    return () => {
      if (synthIntervalRef.current) clearInterval(synthIntervalRef.current);
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {});
      }
    };
  }, [isPlaying, currentTrackIndex]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const nextTrack = () => {
    setCurrentTrackIndex((prev) => (prev + 1) % TRACKS.length);
    setProgress(0);
  };

  const prevTrack = () => {
    setCurrentTrackIndex((prev) => (prev - 1 + TRACKS.length) % TRACKS.length);
    setProgress(0);
  };

  return (
    <div className="h-full bg-linear-to-b from-slate-900 via-indigo-950 to-slate-950 text-white flex flex-col justify-between p-6 select-none">
      {/* Top Header */}
      <div className="text-center">
        <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
          المشغل الصوتي
        </span>
        <h3 className="text-sm text-slate-300 font-medium mt-0.5">{track.album}</h3>
      </div>

      {/* Album Vinyl / Art Display */}
      <div className="flex flex-col items-center justify-center my-6">
        <div
          className={`w-48 h-48 rounded-3xl bg-linear-to-tr ${track.color} shadow-2xl shadow-indigo-500/20 flex items-center justify-center p-3 relative overflow-hidden transition-all duration-700`}
        >
          {/* Animated spinning disc */}
          <div
            className={`w-36 h-36 rounded-full bg-slate-950/80 border-4 border-white/20 flex items-center justify-center shadow-inner ${
              isPlaying ? 'animate-spin-slow' : ''
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
              <Disc className="w-6 h-6 text-white" />
            </div>
          </div>

          {/* Equalizer Wave effect */}
          {isPlaying && (
            <div className="absolute bottom-4 flex gap-1 items-end h-8">
              {[60, 100, 40, 80, 50, 90, 70].map((h, i) => (
                <div
                  key={i}
                  style={{ height: `${h}%` }}
                  className="w-1 bg-white/80 rounded-full animate-pulse"
                />
              ))}
            </div>
          )}
        </div>

        {/* Track Title */}
        <div className="text-center mt-6">
          <h2 className="text-xl font-bold text-white tracking-wide">{track.title}</h2>
          <p className="text-sm text-slate-400 mt-1">{track.artist}</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1">
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div
            className="bg-amber-400 h-full rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between text-[11px] text-slate-400 font-mono">
          <span>0:{String(Math.floor(progress * 0.4)).padStart(2, '0')}</span>
          <span>1:40</span>
        </div>
      </div>

      {/* Playback Controls */}
      <div className="flex items-center justify-center gap-6 my-2">
        <button
          onClick={prevTrack}
          className="p-3 text-slate-300 hover:text-white active:scale-90 transition-transform"
        >
          <SkipBack className="w-6 h-6" />
        </button>

        <button
          onClick={togglePlay}
          className="w-16 h-16 rounded-full bg-white text-slate-950 flex items-center justify-center shadow-xl shadow-white/10 active:scale-90 hover:scale-105 transition-all"
        >
          {isPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 mr-0.5 fill-current" />}
        </button>

        <button
          onClick={nextTrack}
          className="p-3 text-slate-300 hover:text-white active:scale-90 transition-transform"
        >
          <SkipForward className="w-6 h-6" />
        </button>
      </div>

      {/* Volume info */}
      <div className="flex items-center justify-center gap-2 text-slate-400 text-xs">
        <Volume2 className="w-4 h-4" />
        <span>موسيقى لطيفة متزامنة</span>
      </div>
    </div>
  );
};
