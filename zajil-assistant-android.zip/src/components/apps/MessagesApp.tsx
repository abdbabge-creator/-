import React, { useState, useEffect } from 'react';
import { Send, MessageSquare, ArrowRight } from 'lucide-react';

interface MessagesAppProps {
  initialRecipient?: string;
  initialMessage?: string;
}

interface Message {
  id: string;
  sender: 'me' | 'other';
  text: string;
  time: string;
}

export const MessagesApp: React.FC<MessagesAppProps> = ({
  initialRecipient,
  initialMessage,
}) => {
  const [selectedContact, setSelectedContact] = useState<string | null>(
    initialRecipient || null
  );
  const [inputText, setInputText] = useState(initialMessage || '');
  const [messages, setMessages] = useState<Record<string, Message[]>>({
    'ماما': [
      { id: '1', sender: 'other', text: 'السلام عليكم يا بني، كيف حالك اليوم؟', time: '11:20 ص' },
      { id: '2', sender: 'me', text: 'وعليكم السلام يا أمي، كل شيء ممتاز والحمد لله!', time: '11:22 ص' },
    ],
    'أحمد': [
      { id: '1', sender: 'other', text: 'هل سنلتقي اليوم في المساء؟', time: '02:00 م' },
    ],
    'فاطمة': [
      { id: '1', sender: 'other', text: 'أرسلت لك الملفات عبر البريد.', time: 'أمس' },
    ],
  });

  useEffect(() => {
    if (initialRecipient) {
      setSelectedContact(initialRecipient);
    }
    if (initialMessage) {
      setInputText(initialMessage);
    }
  }, [initialRecipient, initialMessage]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !selectedContact) return;

    const newMsg: Message = {
      id: String(Date.now()),
      sender: 'me',
      text: inputText.trim(),
      time: 'الآن',
    };

    setMessages((prev) => ({
      ...prev,
      [selectedContact]: [...(prev[selectedContact] || []), newMsg],
    }));

    setInputText('');
  };

  return (
    <div className="h-full bg-slate-950 text-white flex flex-col p-5 select-none">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          {selectedContact ? (
            <button
              onClick={() => setSelectedContact(null)}
              className="p-1 text-slate-400 hover:text-white rounded-md"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          ) : (
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
          )}
          <h2 className="text-xl font-bold">
            {selectedContact ? selectedContact : 'الرسائل'}
          </h2>
        </div>
      </div>

      {/* Main Content */}
      {selectedContact ? (
        <div className="flex-1 flex flex-col justify-between mt-3 overflow-hidden">
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto space-y-3 pr-1">
            {(messages[selectedContact] || []).map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.sender === 'me' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm ${
                    m.sender === 'me'
                      ? 'bg-cyan-600 text-white rounded-br-xs'
                      : 'bg-slate-800 text-slate-200 rounded-bl-xs'
                  }`}
                >
                  {m.text}
                </div>
                <span className="text-[10px] text-slate-500 mt-1 px-1">{m.time}</span>
              </div>
            ))}
          </div>

          {/* Send Input */}
          <form onSubmit={handleSend} className="mt-3 flex gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="اكتب رسالة..."
              className="flex-1 px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 outline-hidden focus:border-cyan-500"
            />
            <button
              type="submit"
              className="w-11 h-11 rounded-2xl bg-cyan-600 text-white flex items-center justify-center hover:bg-cyan-500 active:scale-95 transition-all shadow-md"
            >
              <Send className="w-4 h-4 rotate-180" />
            </button>
          </form>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto space-y-2 mt-3 pr-1">
          {Object.keys(messages).map((contact) => (
            <div
              key={contact}
              onClick={() => setSelectedContact(contact)}
              className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 cursor-pointer flex items-center justify-between active:scale-98 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-linear-to-tr from-cyan-500 to-blue-600 text-white font-bold flex items-center justify-center text-sm shadow-md">
                  {contact.slice(0, 1)}
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-100">{contact}</div>
                  <div className="text-xs text-slate-400 truncate max-w-[180px] mt-0.5">
                    {messages[contact]?.[messages[contact].length - 1]?.text}
                  </div>
                </div>
              </div>
              <span className="text-[11px] text-slate-500">
                {messages[contact]?.[messages[contact].length - 1]?.time}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
