import React, { useState } from 'react';
import {
  Smartphone,
  CheckCircle2,
  Sliders,
  Code2,
  Zap,
  Info,
  BookOpen,
  Copy,
  Terminal,
  Cpu,
  Layers,
  Settings,
  Flame,
  ArrowRight,
  ShieldCheck,
  PackageCheck,
} from 'lucide-react';
import { AndroidSystemState, AppId } from '../../types';

interface AndroidOverlayManagerAppProps {
  systemState: AndroidSystemState;
  onUpdateSystemState: (partial: Partial<AndroidSystemState>) => void;
  onTriggerTestFlight: (appId: AppId) => void;
}

export const AndroidOverlayManagerApp: React.FC<AndroidOverlayManagerAppProps> = ({
  systemState,
  onUpdateSystemState,
  onTriggerTestFlight,
}) => {
  const [activeTab, setActiveTab] = useState<'control' | 'build_guide' | 'code'>('control');
  const [selectedCodeFile, setSelectedCodeFile] = useState<string>('overlay_service');
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const codeSnippets: Record<string, { title: string; filename: string; code: string }> = {
    overlay_service: {
      title: 'خدمة النافذة العائمة (FloatingOverlayService)',
      filename: 'FloatingOverlayService.kt',
      code: `package com.zajil.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.app.NotificationCompat

class FloatingOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var layoutParams: WindowManager.LayoutParams

    companion object {
        var instance: FloatingOverlayService? = null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }

        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_widget, null)
        windowManager.addView(floatingView, layoutParams)
        setupDragTouch()
    }

    private fun setupDragTouch() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        floatingView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                    layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, layoutParams)
                    true
                }
                else -> false
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}`,
    },
    accessibility: {
      title: 'خدمة إمكانية الوصول والنقر (ZajilAccessibilityService)',
      filename: 'ZajilAccessibilityService.kt',
      code: `package com.zajil.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ZajilAccessibilityService : AccessibilityService() {

    companion object {
        var instance: ZajilAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /**
     * Executes real touch tap at (x, y) coordinates via Android accessibility gesture engine
     */
    fun clickAtCoordinates(x: Float, y: Float, onComplete: (() -> Unit)? = null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val clickPath = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(clickPath, 0, 80)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                    onComplete?.invoke()
                }
            }, null)
        }
    }
}`,
    },
    bridge: {
      title: 'جسر جافاسكريبت المزدوج (AndroidBridge)',
      filename: 'AndroidBridge.kt',
      code: `package com.zajil.assistant

import android.content.Context
import android.webkit.JavascriptInterface
import android.widget.Toast

class AndroidBridge(private val context: Context, private val activity: MainActivity) {

    @JavascriptInterface
    fun requestOverlayPermission() {
        activity.runOnUiThread { activity.checkAndRequestPermissions() }
    }

    @JavascriptInterface
    fun openAccessibilitySettings() {
        activity.runOnUiThread { activity.openAccessibilitySettings() }
    }

    @JavascriptInterface
    fun flyToAndClick(x: Float, y: Float) {
        activity.runOnUiThread {
            FloatingOverlayService.instance?.flyToTargetAndClick(x.toInt(), y.toInt()) {
                ZajilAccessibilityService.instance?.clickAtCoordinates(x, y)
            }
        }
    }

    @JavascriptInterface
    fun isOverlayEnabled(): Boolean {
        return android.provider.Settings.canDrawOverlays(context)
    }

    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }
}`,
    },
    main_activity: {
      title: 'النشاط الرئيسي و WebView (MainActivity)',
      filename: 'MainActivity.kt',
      code: `package com.zajil.assistant

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        setupWebView()
        checkAndRequestPermissions()
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
        }
        webView.addJavascriptInterface(AndroidBridge(this, this), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    fun checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:\$packageName")
            )
            startActivity(intent)
        }
    }
}`,
    },
    manifest: {
      title: 'بيان التطبيق والصلاحيات (AndroidManifest.xml)',
      filename: 'AndroidManifest.xml',
      code: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="زاجل"
        android:theme="@style/Theme.ZajilAssistant">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.ZajilAssistant.Fullscreen">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".FloatingOverlayService"
            android:foregroundServiceType="specialUse"
            android:exported="false" />

        <service
            android:name=".ZajilAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>
    </application>
</manifest>`,
    },
    build_gradle: {
      title: 'إعدادات البناء والمكتبات (app/build.gradle)',
      filename: 'build.gradle (app)',
      code: `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.zajil.assistant'
    compileSdk 34

    defaultConfig {
        applicationId "com.zajil.assistant"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = '1.8'
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.webkit:webkit:1.10.0'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
}`,
    },
    github_workflow: {
      title: 'سير عمل البناء السحابي (build-apk.yml)',
      filename: '.github/workflows/build-apk.yml',
      code: `name: Build Android APK (Zajil Assistant)

on:
  push:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    name: Build Native Android APK
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: |
          npm install
          npm run build
          mkdir -p android/app/src/main/assets/dist
          cp -r dist/* android/app/src/main/assets/
          cp -r dist/* android/app/src/main/assets/dist/
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - run: chmod +x android/gradlew
      - run: cd android && ./gradlew assembleDebug --stacktrace
      - uses: actions/upload-artifact@v4
        with:
          name: zajil-assistant-debug-apk
          path: android/app/build/outputs/apk/debug/app-debug.apk
      - uses: softprops/action-gh-release@v2
        if: startsWith(github.ref, 'refs/tags/') || github.event_name == 'workflow_dispatch'
        with:
          tag_name: v1.0.0-\${{ github.run_number }}
          name: Zajil Assistant APK Release
          files: android/app/build/outputs/apk/debug/app-debug.apk
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}`,
    },
  };

  const handleCopyCode = () => {
    const text = codeSnippets[selectedCodeFile]?.code || '';
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  const copyCommand = (cmd: string, id: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div className="h-full bg-slate-950 text-white flex flex-col p-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800">
        <div className="w-8 h-8 rounded-xl bg-linear-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md">
          <Smartphone className="w-4 h-4" />
        </div>
        <div>
          <h2 className="text-base font-bold text-slate-100">نظام Android Overlay & بناء APK</h2>
          <p className="text-[11px] text-slate-400">التحكم بالنظام العائم وتصدير تطبيق أندرويد حقيقي</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-3 bg-slate-900 p-1 rounded-2xl border border-slate-800 mb-3 gap-1">
        <button
          onClick={() => setActiveTab('control')}
          className={`py-1.5 text-[11px] font-bold rounded-xl flex items-center justify-center gap-1 transition-all ${
            activeTab === 'control' ? 'bg-emerald-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>المحاكاة</span>
        </button>
        <button
          onClick={() => setActiveTab('build_guide')}
          className={`py-1.5 text-[11px] font-bold rounded-xl flex items-center justify-center gap-1 transition-all ${
            activeTab === 'build_guide' ? 'bg-emerald-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>بناء APK سحابياً ☁️</span>
        </button>
        <button
          onClick={() => setActiveTab('control')}
          className={`py-1.5 text-[11px] font-bold rounded-xl flex items-center justify-center gap-1 transition-all ${
            activeTab === 'control' ? 'bg-emerald-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>المحاكاة</span>
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`py-1.5 text-[11px] font-bold rounded-xl flex items-center justify-center gap-1 transition-all ${
            activeTab === 'code' ? 'bg-emerald-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>ملفات الكود</span>
        </button>
      </div>

      {/* Tab: Cloud APK Build & Download Guide (No PC Required) */}
      {activeTab === 'build_guide' && (
        <div className="space-y-3 text-right">
          {/* Main Action Banner: 1-Click ZIP Download for Phone */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-900/60 via-slate-900 to-cyan-950 border border-emerald-500/40 shadow-xl">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold mb-1.5">
              <PackageCheck className="w-4 h-4" />
              <span>بناء APK سحابياً 100% من الهاتف بدون كمبيوتر!</span>
            </div>
            <p className="text-[11px] text-slate-200 leading-relaxed mb-3">
              المشروع مجهز بالكامل مع خدمة GitHub Actions السحابية المجانية لإنشاء ملف APK حقيقي وقابل للتثبيت مباشرة على هاتفك الأندرويد.
            </p>

            {/* Direct Project ZIP Download Button */}
            <a
              href="/api/export/download-project-zip"
              download="zajil-assistant-android.zip"
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all text-center"
            >
              <Smartphone className="w-4 h-4" />
              <span>تحميل مشروع التطبيق كاملاً (ZIP) لهاتفك</span>
            </a>
            <p className="text-[10px] text-slate-400 text-center mt-1.5">
              يحتوي الأرشيف على تطبيق الأندرويد الكامل، والواجهة، وملف البناء السحابي.
            </p>
          </div>

          {/* Cloud Step 1: GitHub via Mobile Chrome */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold">
              <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-[10px] font-bold">
                1
              </span>
              <span>فتح GitHub من متصفح Chrome على الهاتف</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              من هاتفك الأندرويد، افتح متصفح Chrome وتوجه إلى{' '}
              <a
                href="https://github.com/new"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-300 underline font-mono text-[10px]"
              >
                github.com/new
              </a>{' '}
              وقم بإنشاء مستودع جديد (Repository) باسم <code className="text-amber-300">zajil-assistant</code> واجعله عاماً (Public).
            </p>
          </div>

          {/* Cloud Step 2: GitHub Actions Automated Build */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-purple-400 text-xs font-bold">
              <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-[10px] font-bold">
                2
              </span>
              <span>تشغيل خدمة البناء السحابية (GitHub Actions)</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              لقد جهزنا لك ملف البناء الآلي <code className="text-cyan-300 font-mono text-[10px]">.github/workflows/build-apk.yml</code>.
            </p>
            <ol className="text-[11px] text-slate-300 space-y-1 list-decimal list-inside pr-1 leading-relaxed">
              <li>داخل صفحة المستودع في هاتفك، اضغط على تبويب <strong className="text-white">Actions</strong>.</li>
              <li>اختر سير العمل: <strong className="text-emerald-400">Build Android APK (Zajil Assistant)</strong>.</li>
              <li>اضغط على زر <strong className="text-white bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">Run workflow</strong> الأخضر!</li>
              <li>ستبدأ خوادم GitHub السحابية بتثبيت JDK وGradle وبناء ملف APK حقيقي في دقيقتين مجاناً!</li>
            </ol>
          </div>

          {/* Cloud Step 3: Direct APK Download Link */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] font-bold">
                3
              </span>
              <span>رابط التنزيل المباشر لملف APK على الهاتف</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              فور اكتمال البناء (ستظهر علامة صح خضراء ✓)، ستجد ملف الـ APK جاهزاً للتنزيل المباشر:
            </p>
            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 space-y-1">
              <div className="text-[10px] text-slate-400">ملف الإخراج النهائي الحقيقي:</div>
              <div className="font-mono text-[10px] text-emerald-300" dir="ltr">
                app-debug.apk (أو zajil-assistant-debug-apk)
              </div>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              اضغط على الملف وسيبدأ متصفح Chrome بتنزيل ملف الـ APK مباشرة إلى مجلد التنزيلات (Downloads) في هاتفك!
            </p>
          </div>

          {/* Cloud Step 4: Phone Installation Steps */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-amber-500/30 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>طريقة تثبيت الـ APK وتفعيل الصلاحيات على الهاتف خطوة بخطوة:</span>
            </div>
            <ul className="text-[11px] text-slate-300 space-y-1.5 list-disc list-inside pr-1 leading-relaxed">
              <li>
                <strong className="text-white">تثبيت التطبيق:</strong> افتح إشعار التحميل أو تطبيق "ملفاتي" (Files)، واضغط على <strong className="text-emerald-300">app-debug.apk</strong> ثم اختر <strong className="text-white">تثبيت (Install)</strong>. (إذا طلب الإذن، فعّل خيار "السماح بالتثبيت من هذا المصدر / Chrome").
              </li>
              <li>
                <strong className="text-white">إذن الظهور فوق التطبيقات (Overlay):</strong> عند فتح التطبيق، سيطلب تلقائياً إذن الظهور، اضغط عليه وفعّل المفتاح ليظهر الطائر طافياً فوق كل شاشات الهاتف.
              </li>
              <li>
                <strong className="text-white">إمكانية الوصول (Accessibility):</strong> اذهب إلى إعدادات هاتفك &gt; إمكانية الوصول (Accessibility) &gt; التطبيقات المثبتة &gt; اختر <strong className="text-cyan-300">زاجل</strong> &gt; تفعيل (ليستطيع الطائر تنفيذ النقرات الحقيقية بالمنقار على شاشة الهاتف).
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Tab: Control & Simulation */}
      {activeTab === 'control' && (
        <div className="space-y-3.5">
          {/* Honesty Clarification Banner */}
          <div className="p-3 rounded-2xl bg-slate-900/90 border border-amber-500/30 text-right shadow-sm">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold mb-1">
              <Info className="w-4 h-4" />
              <span>بيئة الويب ونظام Android الحقيقي:</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              تعمل هذه المعاينة داخل المتصفح. تمنع سياسات أمان الويب الوصول المباشر
              لصلاحيات نظام أندرويد العميقة (<code className="text-cyan-300 font-mono text-[10px]">AccessibilityService</code> و{' '}
              <code className="text-cyan-300 font-mono text-[10px]">SYSTEM_ALERT_WINDOW</code>) خارج النافذة.
              المشروع مجهز بالكامل في مجلد <code className="text-emerald-400 font-mono text-[10px]">/android</code> لإنشاء ملف APK قابل للتثبيت!
            </p>
          </div>

          {/* Main Switches Card */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              إعدادات الطائر العائم والمحاكاة
            </h3>

            {/* Toggle Floating Overlay */}
            <div className="flex items-center justify-between py-1">
              <div>
                <div className="text-xs font-bold text-slate-100">إظهار الطائر العائم فوق الشاشات</div>
                <div className="text-[10px] text-slate-400">يبقى الطائر ظاهراً وقابلاً للسحب واللمس فوق أي تطبيق</div>
              </div>
              <button
                onClick={() =>
                  onUpdateSystemState({ floatingOverlayEnabled: !systemState.floatingOverlayEnabled })
                }
                className={`w-11 h-6 rounded-full p-1 transition-colors ${
                  systemState.floatingOverlayEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    systemState.floatingOverlayEnabled ? 'translate-x-0' : '-translate-x-5'
                  }`}
                />
              </button>
            </div>

            {/* Toggle Flight & Peck Animation */}
            <div className="flex items-center justify-between py-1 border-t border-slate-800/60 pt-2">
              <div>
                <div className="text-xs font-bold text-slate-100">حركة الطيران والنقر بالمنقار</div>
                <div className="text-[10px] text-slate-400">يطير الطائر إلى أيقونة التطبيق وينقر عليها بمنقاره</div>
              </div>
              <button
                onClick={() =>
                  onUpdateSystemState({ flightAnimationEnabled: !systemState.flightAnimationEnabled })
                }
                className={`w-11 h-6 rounded-full p-1 transition-colors ${
                  systemState.flightAnimationEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    systemState.flightAnimationEnabled ? 'translate-x-0' : '-translate-x-5'
                  }`}
                />
              </button>
            </div>

            {/* Toggle Snap to Edge */}
            <div className="flex items-center justify-between py-1 border-t border-slate-800/60 pt-2">
              <div>
                <div className="text-xs font-bold text-slate-100">المحاذاة التلقائية لحواف الشاشة</div>
                <div className="text-[10px] text-slate-400">ينجذب الطائر لحافة الشاشة عند إفلات السحب</div>
              </div>
              <button
                onClick={() => onUpdateSystemState({ snapToEdges: !systemState.snapToEdges })}
                className={`w-11 h-6 rounded-full p-1 transition-colors ${
                  systemState.snapToEdges ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    systemState.snapToEdges ? 'translate-x-0' : '-translate-x-5'
                  }`}
                />
              </button>
            </div>

            {/* Simulated Accessibility Service Permission */}
            <div className="flex items-center justify-between py-1 border-t border-slate-800/60 pt-2">
              <div>
                <div className="text-xs font-bold text-slate-100">خدمة إمكانية الوصول (Accessibility)</div>
                <div className="text-[10px] text-slate-400">محاكاة إذن تنفيذ النقرات الحقيقية على الشاشة</div>
              </div>
              <button
                onClick={() =>
                  onUpdateSystemState({
                    accessibilityServiceEnabled: !systemState.accessibilityServiceEnabled,
                  })
                }
                className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border transition-all ${
                  systemState.accessibilityServiceEnabled
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                {systemState.accessibilityServiceEnabled ? 'مفعّلة ✓' : 'تفعيل'}
              </button>
            </div>
          </div>

          {/* Test Flight & Automated Click Execution Buttons */}
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              اختبر حركة طيران الطائر والنقر التلقائي:
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'camera' as AppId, title: 'طيران ونقر: الكاميرا 📷' },
                { id: 'calculator' as AppId, title: 'طيران ونقر: الحاسبة 🧮' },
                { id: 'music' as AppId, title: 'طيران ونقر: الموسيقى 🎵' },
                { id: 'notes' as AppId, title: 'طيران ونقر: الملاحظات 📝' },
              ].map((btn) => (
                <button
                  key={btn.id}
                  onClick={() => onTriggerTestFlight(btn.id)}
                  className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-400 text-right text-xs font-bold text-slate-200 active:scale-95 transition-all flex items-center justify-between group"
                >
                  <span>{btn.title}</span>
                  <Zap className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Source Code Inspector */}
      {activeTab === 'code' && (
        <div className="flex-1 flex flex-col space-y-2.5">
          {/* File Picker */}
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {Object.keys(codeSnippets).map((key) => (
              <button
                key={key}
                onClick={() => setSelectedCodeFile(key)}
                className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all ${
                  selectedCodeFile === key
                    ? 'bg-cyan-500 text-slate-950 shadow-md'
                    : 'bg-slate-900 text-slate-400 hover:text-white'
                }`}
              >
                {codeSnippets[key].filename}
              </button>
            ))}
          </div>

          {/* Code Viewer */}
          <div className="relative flex-1 rounded-2xl bg-slate-950 border border-slate-800 p-3 overflow-hidden flex flex-col min-h-[300px]">
            <div className="flex justify-between items-center mb-2 pb-2 border-b border-slate-800">
              <span className="text-[11px] font-mono text-cyan-400">
                {codeSnippets[selectedCodeFile].filename}
              </span>
              <button
                onClick={handleCopyCode}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-white transition-colors flex items-center gap-1"
              >
                {copiedNotification ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>نسخ الملف</span>
                  </>
                )}
              </button>
            </div>

            <pre
              className="flex-1 overflow-x-auto text-[10px] font-mono text-slate-300 leading-relaxed p-2 bg-slate-900/60 rounded-xl"
              dir="ltr"
            >
              {codeSnippets[selectedCodeFile].code}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};

