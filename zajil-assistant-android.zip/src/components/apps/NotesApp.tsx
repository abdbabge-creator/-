import React, { useState, useEffect } from 'react';
import { Plus, Trash2, FileText, Check } from 'lucide-react';
import { NoteItem } from '../../types';

interface NotesAppProps {
  initialNewNote?: string;
}

export const NotesApp: React.FC<NotesAppProps> = ({ initialNewNote }) => {
  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try {
      const saved = localStorage.getItem('zajil_notes');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: '1',
        text: 'شراء بعض البذور والفواكه اللذيذة لطائري الصغير 🍓🍇',
        date: 'اليوم، 10:30 ص',
      },
      {
        id: '2',
        text: 'موعد استشارة الطبيب يوم الأحد القادم بإذن الله',
        date: 'أمس، 04:15 م',
      },
    ];
  });

  const [newText, setNewText] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  // Auto-save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('zajil_notes', JSON.stringify(notes));
    } catch (e) {}
  }, [notes]);

  // When assistant adds a note via voice command
  useEffect(() => {
    if (initialNewNote && initialNewNote.trim()) {
      const newNote: NoteItem = {
        id: String(Date.now()),
        text: initialNewNote,
        date: 'الآن (بواسطة زاجل ✨)',
      };
      setNotes((prev) => [newNote, ...prev]);
    }
  }, [initialNewNote]);

  const handleAddManualNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;
    const note: NoteItem = {
      id: String(Date.now()),
      text: newText.trim(),
      date: 'الآن',
    };
    setNotes((prev) => [note, ...prev]);
    setNewText('');
    setIsAdding(false);
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <div className="h-full bg-slate-950 text-white flex flex-col p-5 select-none">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <FileText className="w-4 h-4" />
          </div>
          <h2 className="text-xl font-bold">الملاحظات</h2>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="w-8 h-8 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-bold hover:bg-amber-400 active:scale-90 transition-all shadow-md"
          title="إضافة ملاحظة جديدة"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Add note drawer if opened */}
      {isAdding && (
        <form onSubmit={handleAddManualNote} className="mb-4 p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <textarea
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            placeholder="اكتب ملاحظتك هنا..."
            rows={3}
            autoFocus
            className="w-full bg-transparent text-sm text-white placeholder-slate-500 outline-hidden resize-none"
          />
          <div className="flex justify-end gap-2 mt-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1 text-xs text-slate-400 hover:text-white"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold flex items-center gap-1 shadow-md hover:bg-amber-400 active:scale-95 transition-all"
            >
              <Check className="w-3.5 h-3.5" />
              <span>حفظ</span>
            </button>
          </div>
        </form>
      )}

      {/* Notes List */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-1">
        {notes.length === 0 ? (
          <div className="h-40 flex flex-col items-center justify-center text-slate-500 text-sm">
            <span>لا توجد ملاحظات بعد</span>
            <span className="text-xs text-slate-600 mt-1">
              يمكنك قول: «يا زاجل، خذ ملاحظة: موعد هام غداً»
            </span>
          </div>
        ) : (
          notes.map((note) => (
            <div
              key={note.id}
              className="p-4 rounded-2xl bg-slate-900 border border-slate-800/80 hover:border-slate-700 transition-all group flex flex-col justify-between"
            >
              <p className="text-sm text-slate-200 leading-relaxed font-normal whitespace-pre-wrap">
                {note.text}
              </p>
              <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-800/50 text-[11px] text-slate-500">
                <span>{note.date}</span>
                <button
                  onClick={() => deleteNote(note.id)}
                  className="text-slate-500 hover:text-rose-400 p-1 rounded-md transition-colors"
                  title="حذف الملاحظة"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
