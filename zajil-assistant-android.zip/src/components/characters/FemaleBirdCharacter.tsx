import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BirdEmotion } from '../../types';
import { playChirp } from '../../utils/audio';

interface FemaleBirdCharacterProps {
  emotion: BirdEmotion;
  isSpeaking: boolean;
  mouthOpen: boolean;
  isListening: boolean;
  onPet?: () => void;
  size?: number;
}

export const FemaleBirdCharacter: React.FC<FemaleBirdCharacterProps> = ({
  emotion,
  isSpeaking,
  mouthOpen,
  isListening,
  onPet,
  size = 180,
}) => {
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 190);
    }, 2800 + Math.random() * 2000);
    return () => clearInterval(blinkInterval);
  }, []);

  const handleClick = () => {
    playChirp('giggle');
    onPet?.();
  };

  const renderEyes = () => {
    if (blink && emotion !== 'surprised') {
      return (
        <g id="female-blinking-eyes">
          <path d="M 68 85 Q 82 88 96 85" stroke="#4C0519" strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d="M 66 84 L 60 80" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 72 87 L 68 92" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />

          <path d="M 124 85 Q 138 88 152 85" stroke="#4C0519" strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d="M 154 84 L 160 80" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 148 87 L 152 92" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />
        </g>
      );
    }

    if (emotion === 'happy' || emotion === 'cheering') {
      return (
        <g id="female-happy-eyes">
          <path d="M 68 86 Q 82 70 96 86" stroke="#4C0519" strokeWidth="5" strokeLinecap="round" fill="none" />
          <path d="M 66 82 L 58 78" stroke="#4C0519" strokeWidth="3" strokeLinecap="round" />
          <path d="M 70 76 L 65 70" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />

          <path d="M 124 86 Q 138 70 152 86" stroke="#4C0519" strokeWidth="5" strokeLinecap="round" fill="none" />
          <path d="M 154 82 L 162 78" stroke="#4C0519" strokeWidth="3" strokeLinecap="round" />
          <path d="M 150 76 L 155 70" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />

          {/* Glowing Rose Blush */}
          <ellipse cx="58" cy="97" rx="10" ry="6" fill="#F43F5E" opacity="0.6" />
          <ellipse cx="162" cy="97" rx="10" ry="6" fill="#F43F5E" opacity="0.6" />
        </g>
      );
    }

    return (
      <g id="female-open-eyes">
        {/* Left Eye */}
        <ellipse cx="82" cy="85" rx="15" ry="19" fill="#FFFFFF" stroke="#4C0519" strokeWidth="3" />
        <ellipse cx={isListening ? 84 : 82} cy="85" rx="9" ry="11" fill="#831843" />
        <ellipse cx={83} cy="86" rx="6" ry="8" fill="#EC4899" />
        {/* Highlights */}
        <circle cx={80} cy={81} r="4.5" fill="#FFFFFF" />
        <circle cx={86} cy={88} r="2" fill="#FFFFFF" />
        {/* Curved Eyelashes */}
        <path d="M 70 74 C 74 69 82 68 88 71" stroke="#4C0519" strokeWidth="3" strokeLinecap="round" fill="none" />
        <path d="M 68 73 L 62 67" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M 74 70 L 71 63" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />

        {/* Right Eye */}
        <ellipse cx="138" cy="85" rx="15" ry="19" fill="#FFFFFF" stroke="#4C0519" strokeWidth="3" />
        <ellipse cx={isListening ? 140 : 138} cy="85" rx="9" ry="11" fill="#831843" />
        <ellipse cx={139} cy="86" rx="6" ry="8" fill="#EC4899" />
        {/* Highlights */}
        <circle cx={136} cy={81} r="4.5" fill="#FFFFFF" />
        <circle cx={142} cy={88} r="2" fill="#FFFFFF" />
        {/* Curved Eyelashes */}
        <path d="M 132 71 C 138 68 146 69 150 74" stroke="#4C0519" strokeWidth="3" strokeLinecap="round" fill="none" />
        <path d="M 152 73 L 158 67" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M 146 70 L 149 63" stroke="#4C0519" strokeWidth="2.5" strokeLinecap="round" />

        {/* Cute Cheek Blush */}
        <ellipse cx="60" cy="98" rx="9" ry="5.5" fill="#FB7185" opacity="0.65" />
        <ellipse cx="160" cy="98" rx="9" ry="5.5" fill="#FB7185" opacity="0.65" />
      </g>
    );
  };

  return (
    <div
      className="relative flex flex-col items-center justify-center cursor-pointer select-none"
      style={{ width: size, height: size }}
      onClick={handleClick}
    >
      {/* Listening Floral Aura */}
      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: [1, 1.35, 1], opacity: [0.6, 0.25, 0.6] }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute inset-0 rounded-full bg-radial from-pink-400/35 via-rose-300/15 to-transparent blur-md pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Speaking Sound Pulsing Waves */}
      <AnimatePresence>
        {isSpeaking && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: [0.95, 1.25, 0.95], opacity: [0.4, 0.8, 0.4] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -inset-4 rounded-full border-2 border-pink-400/40 pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Thinking Sparkle */}
      <AnimatePresence>
        {emotion === 'thinking' && (
          <motion.div
            initial={{ y: 10, opacity: 0, scale: 0.5 }}
            animate={{ y: -30, opacity: 1, scale: 1 }}
            exit={{ y: -40, opacity: 0 }}
            className="absolute -top-3 right-6 bg-pink-500 text-white font-bold text-xs px-2.5 py-1 rounded-full shadow-lg border-2 border-white flex items-center gap-1 z-20 pointer-events-none"
          >
            <span>🌸</span>
            <span>تفكّر...</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Animated SVG Body */}
      <motion.div
        animate={
          isSpeaking
            ? { y: [0, -6, 0], rotate: [0, 2, -2, 0], transition: { duration: 0.45, repeat: Infinity } }
            : isListening
            ? { rotate: [-3, 3, -3], y: [-2, 2, -2], transition: { duration: 1.8, repeat: Infinity } }
            : emotion === 'cheering'
            ? { y: [0, -18, 0], rotate: [0, 8, -8, 0], scale: [1, 1.08, 1], transition: { duration: 0.5, repeat: 3 } }
            : { y: [0, -4, 0], transition: { duration: 2.8, repeat: Infinity, ease: 'easeInOut' } }
        }
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="w-full h-full relative"
      >
        <svg viewBox="0 0 220 220" className="w-full h-full drop-shadow-[0_12px_24px_rgba(244,63,94,0.35)]" fill="none">
          <defs>
            <linearGradient id="femaleBodyGrad" x1="40" y1="20" x2="180" y2="200" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#F472B6" />
              <stop offset="60%" stopColor="#EC4899" />
              <stop offset="100%" stopColor="#DB2777" />
            </linearGradient>

            <linearGradient id="femaleBellyGrad" x1="110" y1="80" x2="110" y2="180" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FCE7F3" />
              <stop offset="100%" stopColor="#FBCFE8" />
            </linearGradient>

            <linearGradient id="femaleBeakGrad" x1="90" y1="85" x2="130" y2="125" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FCD34D" />
              <stop offset="100%" stopColor="#FB923C" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="110" cy="204" rx="55" ry="8" fill="#4C0519" opacity="0.3" />

          {/* Feet */}
          <g id="female-feet">
            <path d="M 82 178 L 74 198 M 82 178 L 82 200 M 82 178 L 90 198" stroke="#F43F5E" strokeWidth="5" strokeLinecap="round" />
            <path d="M 138 178 L 130 198 M 138 178 L 138 200 M 138 178 L 146 198" stroke="#F43F5E" strokeWidth="5" strokeLinecap="round" />
          </g>

          {/* Tail */}
          <path d="M 50 148 C 28 160 18 180 14 195 C 28 188 44 176 60 166 Z" fill="#BE185D" />
          <path d="M 58 152 C 34 168 26 188 22 202 C 38 196 54 184 70 172 Z" fill="#F472B6" />

          {/* Main Body */}
          <path
            d="M 110 36 C 65 36 42 70 42 120 C 42 164 74 186 110 186 C 146 186 178 164 178 120 C 178 70 155 36 110 36 Z"
            fill="url(#femaleBodyGrad)"
            stroke="#9D174D"
            strokeWidth="3.5"
          />

          {/* Soft Cream Belly */}
          <path
            d="M 110 95 C 80 95 68 118 68 145 C 68 170 86 182 110 182 C 134 182 152 170 152 145 C 152 118 140 95 110 95 Z"
            fill="url(#femaleBellyGrad)"
            opacity="0.95"
          />

          {/* Head Flower Ribbon / Hair Accessory */}
          <g id="flower-accessory">
            <circle cx="134" cy="40" r="7" fill="#FDE047" />
            <circle cx="127" cy="35" r="6" fill="#FFFFFF" />
            <circle cx="141" cy="35" r="6" fill="#FFFFFF" />
            <circle cx="127" cy="45" r="6" fill="#FFFFFF" />
            <circle cx="141" cy="45" r="6" fill="#FFFFFF" />
            <circle cx="134" cy="40" r="4" fill="#F59E0B" />
          </g>

          {/* Eyes */}
          {renderEyes()}

          {/* Beak with Lip Sync */}
          <g id="female-beak">
            <path
              d="M 96 98 Q 110 94 124 98 C 122 108 116 118 110 120 C 104 118 98 108 96 98 Z"
              fill="url(#femaleBeakGrad)"
              stroke="#EA580C"
              strokeWidth="2.5"
            />
            {/* Lower Beak Motion */}
            <motion.path
              animate={{
                d: mouthOpen || isSpeaking
                  ? 'M 100 114 Q 110 128 120 114 C 116 122 104 122 100 114 Z'
                  : 'M 102 113 Q 110 116 118 113 C 115 115 105 115 102 113 Z',
              }}
              transition={{ duration: 0.1 }}
              fill="#F97316"
              stroke="#C2410C"
              strokeWidth="2"
            />
            {(mouthOpen || isSpeaking) && <ellipse cx="110" cy="115" rx="5" ry="3" fill="#881337" opacity="0.8" />}
          </g>

          {/* Wings */}
          <motion.path
            d="M 52 110 C 35 125 32 155 48 168 C 58 152 64 135 60 118 Z"
            fill="#BE185D"
            stroke="#9D174D"
            strokeWidth="3"
            animate={isSpeaking ? { rotate: [0, -12, 0], originX: '52px', originY: '110px' } : { rotate: 0 }}
            transition={{ duration: 0.35, repeat: isSpeaking ? Infinity : 1 }}
          />
          <motion.path
            d="M 168 110 C 185 125 188 155 172 168 C 162 152 156 135 160 118 Z"
            fill="#BE185D"
            stroke="#9D174D"
            strokeWidth="3"
            animate={isSpeaking ? { rotate: [0, 12, 0], originX: '168px', originY: '110px' } : { rotate: 0 }}
            transition={{ duration: 0.35, repeat: isSpeaking ? Infinity : 1 }}
          />
        </svg>
      </motion.div>
    </div>
  );
};
