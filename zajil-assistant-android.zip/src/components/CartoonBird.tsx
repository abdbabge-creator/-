import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BirdEmotion } from '../types';
import { playChirp } from '../utils/audio';

interface CartoonBirdProps {
  emotion: BirdEmotion;
  isSpeaking: boolean;
  beakOpen: boolean;
  isListening: boolean;
  onPet?: () => void;
  size?: number;
}

export const CartoonBird: React.FC<CartoonBirdProps> = ({
  emotion,
  isSpeaking,
  beakOpen,
  isListening,
  onPet,
  size = 180,
}) => {
  const [blink, setBlink] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [wiggleKey, setWiggleKey] = useState(0);

  // Periodic eye blinking
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 180);
    }, 3200 + Math.random() * 2000);

    return () => clearInterval(blinkInterval);
  }, []);

  const handleClick = () => {
    setWiggleKey((prev) => prev + 1);
    playChirp('giggle');
    onPet?.();
  };

  // Determine eye expression
  const renderEyes = () => {
    if (blink && emotion !== 'surprised') {
      return (
        <g id="blinking-eyes">
          <path d="M 68 85 Q 82 85 96 85" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d="M 124 85 Q 138 85 152 85" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
        </g>
      );
    }

    if (emotion === 'happy' || emotion === 'cheering') {
      // Curved happy closed eyes (arcs)
      return (
        <g id="happy-eyes">
          <path d="M 68 88 Q 82 72 96 88" stroke="#0F172A" strokeWidth="5" strokeLinecap="round" fill="none" />
          <path d="M 124 88 Q 138 72 152 88" stroke="#0F172A" strokeWidth="5" strokeLinecap="round" fill="none" />
          {/* Cute blush cheeks */}
          <ellipse cx="60" cy="98" rx="9" ry="5" fill="#FB7185" opacity="0.65" />
          <ellipse cx="160" cy="98" rx="9" ry="5" fill="#FB7185" opacity="0.65" />
        </g>
      );
    }

    if (emotion === 'sleepy') {
      return (
        <g id="sleepy-eyes">
          <path d="M 70 88 Q 82 96 94 88" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d="M 126 88 Q 138 96 150 88" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
        </g>
      );
    }

    // Default open cartoon eyes with deep gloss and pupils
    return (
      <g id="normal-eyes">
        {/* Left Eye White */}
        <ellipse cx="82" cy="85" rx="15" ry="19" fill="#FFFFFF" stroke="#0F172A" strokeWidth="3" />
        {/* Left Pupil */}
        <ellipse
          cx={emotion === 'thinking' ? 78 : isListening ? 84 : 82}
          cy={emotion === 'thinking' ? 78 : 85}
          rx="9"
          ry="11"
          fill="#1E1B4B"
        />
        {/* Left Iris Glow */}
        <ellipse
          cx={emotion === 'thinking' ? 79 : 83}
          cy={emotion === 'thinking' ? 79 : 86}
          rx="6"
          ry="8"
          fill="#0284C7"
        />
        {/* Left Specular Highlights */}
        <circle cx={emotion === 'thinking' ? 76 : 80} cy={emotion === 'thinking' ? 75 : 81} r="4" fill="#FFFFFF" />
        <circle cx={emotion === 'thinking' ? 82 : 86} cy={emotion === 'thinking' ? 82 : 88} r="1.8" fill="#FFFFFF" />

        {/* Right Eye White */}
        <ellipse cx="138" cy="85" rx="15" ry="19" fill="#FFFFFF" stroke="#0F172A" strokeWidth="3" />
        {/* Right Pupil */}
        <ellipse
          cx={emotion === 'thinking' ? 134 : isListening ? 140 : 138}
          cy={emotion === 'thinking' ? 78 : 85}
          rx="9"
          ry="11"
          fill="#1E1B4B"
        />
        {/* Right Iris Glow */}
        <ellipse
          cx={emotion === 'thinking' ? 135 : 139}
          cy={emotion === 'thinking' ? 79 : 86}
          rx="6"
          ry="8"
          fill="#0284C7"
        />
        {/* Right Specular Highlights */}
        <circle cx={emotion === 'thinking' ? 132 : 136} cy={emotion === 'thinking' ? 75 : 81} r="4" fill="#FFFFFF" />
        <circle cx={emotion === 'thinking' ? 138 : 142} cy={emotion === 'thinking' ? 82 : 88} r="1.8" fill="#FFFFFF" />

        {/* Cheerful Blush */}
        <ellipse cx="62" cy="98" rx="8" ry="5" fill="#FB7185" opacity="0.55" />
        <ellipse cx="158" cy="98" rx="8" ry="5" fill="#FB7185" opacity="0.55" />
      </g>
    );
  };

  return (
    <div
      className="relative flex flex-col items-center justify-center cursor-pointer select-none"
      style={{ width: size, height: size }}
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      title="اضغط على الطائر لمداعبته"
    >
      {/* Listening Wave Aura */}
      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{
              scale: [1, 1.35, 1],
              opacity: [0.6, 0.2, 0.6],
            }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{
              duration: 1.6,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="absolute inset-0 rounded-full bg-radial from-cyan-400/30 via-emerald-400/15 to-transparent blur-md pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Speaking Sound Pulsing Waves */}
      <AnimatePresence>
        {isSpeaking && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{
              scale: [0.95, 1.25, 0.95],
              opacity: [0.4, 0.8, 0.4],
            }}
            exit={{ opacity: 0 }}
            transition={{
              duration: 0.7,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="absolute -inset-4 rounded-full border-2 border-amber-400/40 pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Thought / Emotion Emoticon */}
      <AnimatePresence>
        {emotion === 'thinking' && (
          <motion.div
            initial={{ y: 10, opacity: 0, scale: 0.5 }}
            animate={{ y: -30, opacity: 1, scale: 1 }}
            exit={{ y: -40, opacity: 0 }}
            className="absolute -top-3 right-6 bg-amber-400 text-slate-900 font-bold text-xs px-2.5 py-1 rounded-full shadow-lg border-2 border-white flex items-center gap-1 z-20 pointer-events-none"
          >
            <motion.span
              animate={{ rotate: [0, 20, -20, 0] }}
              transition={{ repeat: Infinity, duration: 1 }}
            >
              💭
            </motion.span>
            <span>يفكر...</span>
          </motion.div>
        )}

        {emotion === 'cheering' && (
          <motion.div
            initial={{ y: 0, opacity: 0, scale: 0 }}
            animate={{ y: -28, opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="absolute -top-3 bg-emerald-500 text-white font-black text-xs px-2.5 py-1 rounded-full shadow-lg border-2 border-white z-20 pointer-events-none"
          >
            ✨ رائع!
          </motion.div>
        )}

        {isListening && (
          <motion.div
            initial={{ y: 0, opacity: 0, scale: 0 }}
            animate={{ y: -24, opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="absolute -top-3 bg-cyan-600 text-white font-bold text-xs px-2 py-0.5 rounded-full shadow-md border border-white/60 z-20 pointer-events-none flex items-center gap-1"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping" />
            <span>يستمع...</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Animated Bird Character SVG */}
      <motion.div
        key={wiggleKey}
        animate={
          isSpeaking
            ? {
                y: [0, -7, 0],
                rotate: [0, 2, -2, 0],
                transition: { duration: 0.45, repeat: Infinity, ease: 'easeInOut' },
              }
            : isListening
            ? {
                rotate: [-4, 4, -4],
                y: [-2, 2, -2],
                transition: { duration: 1.8, repeat: Infinity, ease: 'easeInOut' },
              }
            : emotion === 'cheering'
            ? {
                y: [0, -18, 0],
                rotate: [0, 10, -10, 0],
                scale: [1, 1.08, 1],
                transition: { duration: 0.5, repeat: 3 },
              }
            : {
                y: [0, -5, 0],
                transition: { duration: 2.8, repeat: Infinity, ease: 'easeInOut' },
              }
        }
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.94 }}
        className="w-full h-full relative"
      >
        <svg
          viewBox="0 0 220 220"
          className="w-full h-full drop-shadow-[0_12px_24px_rgba(14,165,233,0.35)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Feathers Gradient - Cyan to Aqua Turquoise */}
            <linearGradient id="birdBodyGrad" x1="40" y1="20" x2="180" y2="200" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#38BDF8" />
              <stop offset="50%" stopColor="#0EA5E9" />
              <stop offset="100%" stopColor="#0284C7" />
            </linearGradient>

            {/* Belly Gradient - Warm Cream / Sunny Yellow */}
            <linearGradient id="birdBellyGrad" x1="110" y1="80" x2="110" y2="180" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FEF08A" />
              <stop offset="100%" stopColor="#FACC15" />
            </linearGradient>

            {/* Beak Gradient */}
            <linearGradient id="beakGrad" x1="90" y1="85" x2="130" y2="125" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FBBF24" />
              <stop offset="100%" stopColor="#F97316" />
            </linearGradient>

            {/* Crest Gradient */}
            <linearGradient id="crestGrad" x1="110" y1="10" x2="110" y2="50" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#67E8F9" />
              <stop offset="100%" stopColor="#0EA5E9" />
            </linearGradient>

            {/* Feet Gradient */}
            <linearGradient id="feetGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F97316" />
              <stop offset="100%" stopColor="#EA580C" />
            </linearGradient>
          </defs>

          {/* Shadow underneath */}
          <ellipse cx="110" cy="204" rx="55" ry="8" fill="#0F172A" opacity="0.35" />

          {/* Feet Claws */}
          <g id="feet">
            <path
              d="M 82 178 L 72 198 M 82 178 L 82 200 M 82 178 L 92 198"
              stroke="url(#feetGrad)"
              strokeWidth="5.5"
              strokeLinecap="round"
            />
            <path
              d="M 138 178 L 128 198 M 138 178 L 138 200 M 138 178 L 148 198"
              stroke="url(#feetGrad)"
              strokeWidth="5.5"
              strokeLinecap="round"
            />
          </g>

          {/* Tail Feathers */}
          <g id="tail">
            <path d="M 52 145 C 30 155 20 175 16 190 C 28 185 45 175 62 165 Z" fill="#0284C7" />
            <path d="M 60 148 C 36 165 28 185 24 200 C 38 195 56 182 72 170 Z" fill="#38BDF8" />
          </g>

          {/* Main Body (Cute round plum shape) */}
          <path
            d="M 110 36 C 65 36 42 70 42 120 C 42 164 74 186 110 186 C 146 186 178 164 178 120 C 178 70 155 36 110 36 Z"
            fill="url(#birdBodyGrad)"
            stroke="#0369A1"
            strokeWidth="3.5"
          />

          {/* Golden Belly Fluff */}
          <path
            d="M 110 95 C 80 95 68 118 68 145 C 68 170 86 182 110 182 C 134 182 152 170 152 145 C 152 118 140 95 110 95 Z"
            fill="url(#birdBellyGrad)"
            opacity="0.95"
          />

          {/* Cute Feathery Tuft / Crest on Top of Head */}
          <g id="head-crest">
            <path
              d="M 110 38 C 110 16 122 8 132 14 C 136 17 132 28 120 34 Z"
              fill="url(#crestGrad)"
              stroke="#0369A1"
              strokeWidth="2.5"
            />
            <path
              d="M 104 38 C 96 20 86 14 80 20 C 76 25 86 32 96 36 Z"
              fill="url(#crestGrad)"
              stroke="#0369A1"
              strokeWidth="2.5"
            />
          </g>

          {/* Eyes & Eyebrows */}
          {renderEyes()}

          {/* Beak with Dynamic Talking Lip-Sync Movement */}
          <g id="beak">
            {/* Upper Beak */}
            <path
              d="M 96 98 Q 110 94 124 98 C 122 108 116 118 110 120 C 104 118 98 108 96 98 Z"
              fill="url(#beakGrad)"
              stroke="#D97706"
              strokeWidth="2.5"
            />
            {/* Upper Beak Highlight */}
            <path d="M 102 101 Q 110 98 118 101" stroke="#FEF08A" strokeWidth="2" strokeLinecap="round" />

            {/* Lower Beak (Animates open/close with beakOpen state or isSpeaking) */}
            <motion.path
              animate={{
                d: beakOpen || (isSpeaking && !blink)
                  ? 'M 100 114 Q 110 128 120 114 C 116 122 104 122 100 114 Z'
                  : 'M 102 113 Q 110 116 118 113 C 115 115 105 115 102 113 Z',
              }}
              transition={{ duration: 0.1 }}
              fill="#D97706"
              stroke="#B45309"
              strokeWidth="2"
            />

            {/* Mouth Interior Depth when open */}
            {(beakOpen || isSpeaking) && (
              <ellipse cx="110" cy="115" rx="5" ry="3" fill="#881337" opacity="0.8" />
            )}
          </g>

          {/* Left Wing (Animated on speech / cheer) */}
          <motion.path
            id="left-wing"
            d="M 52 110 C 35 125 32 155 48 168 C 58 152 64 135 60 118 Z"
            fill="#0284C7"
            stroke="#0369A1"
            strokeWidth="3"
            animate={
              isSpeaking
                ? { rotate: [0, -12, 0], originX: '52px', originY: '110px' }
                : emotion === 'cheering'
                ? { rotate: [0, -35, -15, -35, 0], originX: '52px', originY: '110px' }
                : { rotate: 0 }
            }
            transition={{ duration: 0.35, repeat: isSpeaking ? Infinity : 1 }}
          />

          {/* Right Wing (Animated on speech / cheer) */}
          <motion.path
            id="right-wing"
            d="M 168 110 C 185 125 188 155 172 168 C 162 152 156 135 160 118 Z"
            fill="#0284C7"
            stroke="#0369A1"
            strokeWidth="3"
            animate={
              isSpeaking
                ? { rotate: [0, 12, 0], originX: '168px', originY: '110px' }
                : emotion === 'cheering'
                ? { rotate: [0, 35, 15, 35, 0], originX: '168px', originY: '110px' }
                : { rotate: 0 }
            }
            transition={{ duration: 0.35, repeat: isSpeaking ? Infinity : 1 }}
          />
        </svg>
      </motion.div>
    </div>
  );
};
