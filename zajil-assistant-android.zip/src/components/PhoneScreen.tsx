import React, { useState, useEffect } from 'react';
import {
  Camera,
  Calculator,
  CloudSun,
  Clock,
  Music,
  FileText,
  Phone,
  MessageSquare,
  Settings,
  Image as ImageIcon,
  Flashlight,
  Wifi,
  BatteryCharging,
  ArrowRight,
  Mic,
  MicOff,
  Keyboard,
  Send,
  Sparkles,
  Wand2,
  Bell,
  Square,
  Circle,
  Triangle,
  Smartphone,
} from 'lucide-react';
import { AppId, BirdEmotion, PermissionsState, CharacterId, VoiceGender, AndroidSystemState } from '../types';
import { CharacterRenderer } from './characters/CharacterRenderer';
import { CHARACTER_PROFILES } from './characters/characterProfiles';
import { AndroidFloatingAssistant, FlightTarget } from './AndroidFloatingAssistant';
import { CharacterCustomizerApp } from './apps/CharacterCustomizerApp';
import { AndroidOverlayManagerApp } from './apps/AndroidOverlayManagerApp';
import { CameraApp } from './apps/CameraApp';
import { CalculatorApp } from './apps/CalculatorApp';
import { WeatherApp } from './apps/WeatherApp';
import { ClockApp } from './apps/ClockApp';
import { MusicApp } from './apps/MusicApp';
import { NotesApp } from './apps/NotesApp';
import { PhoneApp } from './apps/PhoneApp';
import { MessagesApp } from './apps/MessagesApp';
import { SettingsApp } from './apps/SettingsApp';
import { GalleryApp } from './apps/GalleryApp';
import { playChirp, playRobotBeep, playHumanChime } from '../utils/audio';

interface PhoneScreenProps {
  // Character states
  selectedCharacter: CharacterId;
  onSelectCharacter: (id: CharacterId) => void;
  voiceGender: VoiceGender;
  onSelectVoiceGender: (gender: VoiceGender) => void;
  onTestVoice: (greeting: string, gender: VoiceGender) => void;

  // Emotion & animation states
  birdEmotion: BirdEmotion;
  isSpeaking: boolean;
  beakOpen: boolean;
  isListening: boolean;
  onToggleListening: () => void;
  onSendCommand: (cmd: string) => void;
  onPetBird: () => void;

  // Android System Overlay State
  systemState: AndroidSystemState;
  onUpdateSystemState: (partial: Partial<AndroidSystemState>) => void;

  // Active App & context
  activeApp: AppId | null;
  onOpenApp: (app: AppId) => void;
  onCloseApp: () => void;
  appPayload?: any;

  // Permissions
  permissions: PermissionsState;
  onRequestPermission: (name: keyof PermissionsState) => Promise<boolean>;

  // Voice settings
  voicePitch: number;
  setVoicePitch: (pitch: number) => void;
  voiceRate: number;
  setVoiceRate: (rate: number) => void;

  // Captured photos
  photos: string[];
  onPhotoTaken: (url: string) => void;

  // Flashlight state
  flashlightOn: boolean;
  onToggleFlashlight: () => void;
}

export const PhoneScreen: React.FC<PhoneScreenProps> = ({
  selectedCharacter,
  onSelectCharacter,
  voiceGender,
  onSelectVoiceGender,
  onTestVoice,
  birdEmotion,
  isSpeaking,
  beakOpen,
  isListening,
  onToggleListening,
  onSendCommand,
  onPetBird,
  systemState,
  onUpdateSystemState,
  activeApp,
  onOpenApp,
  onCloseApp,
  appPayload,
  permissions,
  onRequestPermission,
  voicePitch,
  setVoicePitch,
  voiceRate,
  setVoiceRate,
  photos,
  onPhotoTaken,
  flashlightOn,
  onToggleFlashlight,
}) => {
  const [currentTime, setCurrentTime] = useState('');
  const [currentDate, setCurrentDate] = useState('');
  const [wallpaper, setWallpaper] = useState('mesh');
  const [showKeyboardInput, setShowKeyboardInput] = useState(false);
  const [typedCommand, setTypedCommand] = useState('');
  const [flightTarget, setFlightTarget] = useState<FlightTarget | null>(null);

  const currentProfile = CHARACTER_PROFILES[selectedCharacter] || CHARACTER_PROFILES.male_bird;

  // Screen Bounds for drag clamping
  const phoneBounds = { width: 376, height: 810 };

  // Map of Screen Coordinates for each App icon on the Home Screen (in LTR overlay coordinates)
  const appCoordinates: Record<AppId, { x: number; y: number; title: string }> = {
    customizer: { x: 275, y: 440, title: 'تخصيص الشخصية' },
    calculator: { x: 195, y: 440, title: 'الحاسبة' },
    weather: { x: 115, y: 440, title: 'الطقس' },
    clock: { x: 35, y: 440, title: 'الساعة' },
    music: { x: 275, y: 520, title: 'الموسيقى' },
    notes: { x: 195, y: 520, title: 'الملاحظات' },
    gallery: { x: 115, y: 520, title: 'الصور' },
    android_service: { x: 35, y: 520, title: 'خدمات أندرويد' },
    phone: { x: 295, y: 640, title: 'الهاتف' },
    messages: { x: 225, y: 640, title: 'الرسائل' },
    camera: { x: 155, y: 640, title: 'الكاميرا' },
    settings: { x: 25, y: 640, title: 'الإعدادات' },
    maps: { x: 115, y: 520, title: 'الخرائط' },
  };

  // Launch App with Flight & Peck Animation if enabled
  const triggerAppLaunchWithFlight = (targetApp: AppId) => {
    if (systemState.flightAnimationEnabled && !activeApp && appCoordinates[targetApp]) {
      const coord = appCoordinates[targetApp];
      setFlightTarget({
        x: coord.x,
        y: coord.y,
        appId: targetApp,
        appName: coord.title,
      });
    } else {
      onOpenApp(targetApp);
    }
  };

  const handleFlightComplete = (appId: AppId) => {
    setFlightTarget(null);
    onOpenApp(appId);
  };

  // Update clock every 10 seconds
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
      );
      setCurrentDate(
        now.toLocaleDateString('ar-SA', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedCommand.trim()) return;
    onSendCommand(typedCommand.trim());
    setTypedCommand('');
    setShowKeyboardInput(false);
  };

  const handlePetInteraction = () => {
    if (selectedCharacter === 'smart_robot') playRobotBeep('giggle');
    else if (selectedCharacter === 'cartoon_human') playHumanChime('giggle');
    else playChirp('giggle');
    onPetBird();
  };

  const wallpaperClasses: Record<string, string> = {
    mesh: 'bg-radial-[at_top_right] from-indigo-900 via-slate-950 to-purple-950',
    desert: 'bg-radial-[at_top_right] from-amber-950 via-rose-950 to-slate-950',
    ocean: 'bg-radial-[at_top_right] from-cyan-950 via-blue-950 to-slate-950',
    emerald: 'bg-radial-[at_top_right] from-emerald-950 via-teal-950 to-slate-950',
  };

  const appIcons = [
    { id: 'customizer' as AppId, title: 'تخصيص الشخصية', icon: Wand2, color: 'bg-linear-to-tr from-purple-500 to-indigo-600', ring: 'ring-purple-400/40' },
    { id: 'calculator' as AppId, title: 'الحاسبة', icon: Calculator, color: 'bg-linear-to-tr from-amber-500 to-orange-600', ring: 'ring-amber-400/40' },
    { id: 'weather' as AppId, title: 'الطقس', icon: CloudSun, color: 'bg-linear-to-tr from-sky-400 to-blue-600', ring: 'ring-sky-400/40' },
    { id: 'clock' as AppId, title: 'الساعة', icon: Clock, color: 'bg-linear-to-tr from-violet-500 to-purple-600', ring: 'ring-violet-400/40' },
    { id: 'music' as AppId, title: 'الموسيقى', icon: Music, color: 'bg-linear-to-tr from-red-500 to-rose-600', ring: 'ring-red-400/40' },
    { id: 'notes' as AppId, title: 'الملاحظات', icon: FileText, color: 'bg-linear-to-tr from-amber-400 to-yellow-600', ring: 'ring-amber-400/40' },
    { id: 'gallery' as AppId, title: 'الصور', icon: ImageIcon, color: 'bg-linear-to-tr from-fuchsia-500 to-pink-600', ring: 'ring-fuchsia-400/40' },
    { id: 'android_service' as AppId, title: 'خدمات أندرويد', icon: Smartphone, color: 'bg-linear-to-tr from-emerald-500 to-teal-600', ring: 'ring-emerald-400/40' },
    { id: 'camera' as AppId, title: 'الكاميرا', icon: Camera, color: 'bg-linear-to-tr from-rose-500 to-pink-600', ring: 'ring-rose-400/40' },
    { id: 'phone' as AppId, title: 'الهاتف', icon: Phone, color: 'bg-linear-to-tr from-emerald-500 to-teal-600', ring: 'ring-emerald-400/40' },
    { id: 'messages' as AppId, title: 'الرسائل', icon: MessageSquare, color: 'bg-linear-to-tr from-cyan-500 to-blue-600', ring: 'ring-cyan-400/40' },
    { id: 'settings' as AppId, title: 'الإعدادات', icon: Settings, color: 'bg-linear-to-tr from-slate-600 to-slate-800', ring: 'ring-slate-400/40' },
  ];

  // Quick suggestions chips for testing voice
  const quickChips = [
    'تخصيص الشخصية',
    'افتح الكاميرا',
    'احسب 25 في 4',
    'شغل موسيقى',
    'خدمات أندرويد',
    'ما هو الطقس؟',
    'اضبط مؤقت دقيقة',
    'احكِ لي نكتة',
    'اتصل بماما',
  ];

  return (
    <div className="relative w-full max-w-[400px] h-[835px] rounded-[48px] p-3 bg-gradient-to-b from-slate-700 via-slate-800 to-slate-900 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8),0_0_0_1.5px_rgba(255,255,255,0.12)] flex flex-col select-none transition-all">
      {/* Metallic Outer Chassis Glint */}
      <div className="absolute inset-0 rounded-[48px] pointer-events-none border border-white/15 shadow-inner" />

      {/* Android Screen Frame */}
      <div
        className={`relative w-full h-full rounded-[38px] overflow-hidden flex flex-col justify-between ${
          wallpaperClasses[wallpaper] || wallpaperClasses.mesh
        } text-white shadow-2xl`}
      >
        {/* Flashlight Bright Beam Overlay */}
        {flashlightOn && (
          <div className="absolute inset-0 bg-white/90 z-40 pointer-events-none animate-pulse flex items-center justify-center">
            <div className="text-slate-900 font-bold bg-white/80 px-4 py-2 rounded-full shadow-lg">
              🔦 المصباح يعمل
            </div>
          </div>
        )}

        {/* ANDROID FLOATING ASSISTANT OVERLAY (Active over home screen AND over open apps!) */}
        {systemState.floatingOverlayEnabled && (
          <AndroidFloatingAssistant
            selectedCharacter={selectedCharacter}
            emotion={birdEmotion}
            isSpeaking={isSpeaking}
            beakOpen={beakOpen}
            isListening={isListening}
            onToggleListening={onToggleListening}
            onOpenCustomizer={() => onOpenApp('customizer')}
            onPet={handlePetInteraction}
            flightTarget={flightTarget}
            onFlightComplete={handleFlightComplete}
            snapToEdges={systemState.snapToEdges}
            containerBounds={phoneBounds}
            activeApp={activeApp}
          />
        )}

        {/* ANDROID STATUS BAR with punch hole camera & Android icons */}
        <div className="relative z-30 px-5 pt-2.5 pb-1 flex items-center justify-between text-xs font-semibold text-white/90">
          <div className="flex items-center gap-2">
            <span className="font-mono tracking-wide text-xs">{currentTime || '12:30'}</span>
            <div className="flex items-center gap-1 opacity-70">
              <Bell className="w-3 h-3 text-cyan-300" />
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            </div>
          </div>

          <div className="w-4 h-4 rounded-full bg-black border border-slate-700 flex items-center justify-center shadow-inner">
            <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
          </div>

          <div className="flex items-center gap-1.5 text-white/90">
            <span className="text-[10px] font-bold tracking-tight text-white/80">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center gap-1 bg-white/10 px-1.5 py-0.5 rounded-md border border-white/10">
              <span className="text-[10px] font-mono">95%</span>
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* ACTIVE APP VIEWPORT (If an app is open) */}
        {activeApp ? (
          <div className="relative flex-1 w-full overflow-hidden flex flex-col bg-slate-950">
            {/* In-App Top Navigation Bar */}
            <div className="px-4 py-2 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 flex items-center justify-between z-20">
              <button
                onClick={onCloseApp}
                className="flex items-center gap-1 text-xs font-bold text-amber-400 hover:text-amber-300 active:scale-95 transition-transform"
              >
                <ArrowRight className="w-4 h-4" />
                <span>الرئيسية</span>
              </button>

              <span className="text-xs font-bold text-slate-300">
                {appIcons.find((a) => a.id === activeApp)?.title}
              </span>

              {/* Status Pill */}
              <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-800 border border-slate-700">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[10px] text-slate-300 font-bold">{currentProfile.name}</span>
              </div>
            </div>

            {/* App Body Content */}
            <div className="flex-1 overflow-hidden relative">
              {activeApp === 'android_service' && (
                <AndroidOverlayManagerApp
                  systemState={systemState}
                  onUpdateSystemState={onUpdateSystemState}
                  onTriggerTestFlight={triggerAppLaunchWithFlight}
                />
              )}
              {activeApp === 'customizer' && (
                <CharacterCustomizerApp
                  selectedCharacter={selectedCharacter}
                  onSelectCharacter={onSelectCharacter}
                  voiceGender={voiceGender}
                  onSelectVoiceGender={onSelectVoiceGender}
                  voicePitch={voicePitch}
                  setVoicePitch={setVoicePitch}
                  voiceRate={voiceRate}
                  setVoiceRate={setVoiceRate}
                  onTestVoice={onTestVoice}
                  isSpeaking={isSpeaking}
                  mouthOpen={beakOpen}
                />
              )}
              {activeApp === 'camera' && (
                <CameraApp
                  hasPermission={permissions.camera}
                  onRequestPermission={() => onRequestPermission('camera')}
                  onPhotoTaken={onPhotoTaken}
                  onOpenGallery={() => onOpenApp('gallery')}
                />
              )}
              {activeApp === 'calculator' && (
                <CalculatorApp
                  initialExpression={appPayload?.calcExpression}
                  initialResult={appPayload?.calcResult}
                />
              )}
              {activeApp === 'weather' && (
                <WeatherApp
                  initialCity={appPayload?.city}
                  hasLocationPermission={permissions.geolocation}
                  onRequestLocationPermission={() => onRequestPermission('geolocation')}
                />
              )}
              {activeApp === 'clock' && (
                <ClockApp initialTimerSeconds={appPayload?.durationSeconds} />
              )}
              {activeApp === 'music' && <MusicApp autoPlay={true} />}
              {activeApp === 'notes' && <NotesApp initialNewNote={appPayload?.noteText} />}
              {activeApp === 'phone' && (
                <PhoneApp
                  initialContactName={appPayload?.contactName}
                  initialPhoneNumber={appPayload?.phoneNumber}
                />
              )}
              {activeApp === 'messages' && (
                <MessagesApp
                  initialRecipient={appPayload?.contactName}
                  initialMessage={appPayload?.messageText}
                />
              )}
              {activeApp === 'settings' && (
                <SettingsApp
                  permissions={permissions}
                  onTogglePermission={onRequestPermission}
                  voicePitch={voicePitch}
                  setVoicePitch={setVoicePitch}
                  voiceRate={voiceRate}
                  setVoiceRate={setVoiceRate}
                  wallpaper={wallpaper}
                  setWallpaper={setWallpaper}
                  selectedCharacter={selectedCharacter}
                  voiceGender={voiceGender}
                  onSelectVoiceGender={onSelectVoiceGender}
                  onOpenCharacterCustomizer={() => onOpenApp('customizer')}
                />
              )}
              {activeApp === 'gallery' && (
                <GalleryApp photos={photos} />
              )}
            </div>
          </div>
        ) : (
          /* HOME SCREEN VIEW */
          <div className="relative flex-1 flex flex-col justify-between px-4 pt-2 pb-1 overflow-y-auto">
            {/* Header Widgets: Date, Time & Character Quick Switcher */}
            <div className="flex justify-between items-start pt-1">
              <div>
                <div className="text-xs text-amber-300 font-semibold">{currentDate}</div>
                <div className="text-3xl font-extrabold tracking-tight font-mono text-white mt-0.5">
                  {currentTime}
                </div>
              </div>

              {/* Character Quick Switcher Button */}
              <button
                onClick={() => onOpenApp('customizer')}
                className="px-3 py-1.5 rounded-2xl bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 flex items-center gap-2 active:scale-95 transition-all shadow-md group"
                title="تخصيص الشخصية والصوت"
              >
                <div className={`w-6 h-6 rounded-lg ${currentProfile.avatarBg} flex items-center justify-center text-xs shadow-xs`}>
                  {selectedCharacter === 'male_bird'
                    ? '🐦'
                    : selectedCharacter === 'female_bird'
                    ? '🌸'
                    : selectedCharacter === 'smart_robot'
                    ? '🤖'
                    : '🧑'}
                </div>
                <div className="text-right">
                  <div className="text-[11px] font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {currentProfile.name}
                  </div>
                  <div className="text-[9px] text-slate-300">
                    {voiceGender === 'female' ? 'صوت أنثى' : 'صوت ذكر'}
                  </div>
                </div>
              </button>
            </div>

            {/* MAIN ASSISTANT SHOWCASE (When Floating Overlay is disabled, shows large centered mascot) */}
            {!systemState.floatingOverlayEnabled ? (
              <div className="relative my-auto flex flex-col items-center justify-center py-1">
                <div className="relative flex items-center justify-center">
                  <CharacterRenderer
                    characterId={selectedCharacter}
                    emotion={birdEmotion}
                    isSpeaking={isSpeaking}
                    mouthOpen={beakOpen}
                    isListening={isListening}
                    onPet={handlePetInteraction}
                    size={185}
                  />
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-white/70">
                  {isListening ? (
                    <span className="text-cyan-300 font-bold flex items-center gap-1 animate-pulse">
                      <span className="w-2 h-2 rounded-full bg-cyan-400" />
                      {currentProfile.name} يستمع لصوتك الآن...
                    </span>
                  ) : isSpeaking ? (
                    <span className="text-amber-300 font-bold flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                      {currentProfile.name} يتحدث إليك بصوته 🔊
                    </span>
                  ) : (
                    <span className="text-slate-300/80 text-[11px]">
                      {currentProfile.name} ({currentProfile.title}) • اضغط وتحدث
                    </span>
                  )}
                </div>
              </div>
            ) : (
              /* If Floating Overlay is active: Quick Action Card with Direct ZIP Download for Mobile */
              <div className="my-auto py-2.5 px-3 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-slate-900/80 border border-emerald-500/40 backdrop-blur-xs flex items-center justify-between shadow-lg">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <div className="text-right">
                    <div className="text-[11px] text-emerald-300 font-bold">بناء APK لهاتفك (سحابياً)</div>
                    <div className="text-[9px] text-slate-300">اضغط الزر لتحميل ملفات المشروع لهاتفك</div>
                  </div>
                </div>
                <a
                  href="/api/export/download-project-zip"
                  download="zajil-assistant-android.zip"
                  className="text-[10px] bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 px-3 py-1.5 rounded-xl font-black shadow-md active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
                >
                  <span>تحميل ZIP</span>
                  <span>📥</span>
                </a>
              </div>
            )}

            {/* Quick Voice Command Chips */}
            <div className="my-1">
              <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                {quickChips.map((chip, i) => (
                  <button
                    key={i}
                    onClick={() => onSendCommand(chip)}
                    className="whitespace-nowrap px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/25 active:scale-95 text-white/90 border border-white/10 backdrop-blur-md transition-all flex items-center gap-1"
                  >
                    <Sparkles className="w-2.5 h-2.5 text-amber-300" />
                    <span>{chip}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* App Grid with Flight Animation Target Integration */}
            <div className="grid grid-cols-4 gap-2.5 my-1.5">
              {appIcons.slice(0, 8).map((app) => {
                const IconComponent = app.icon;
                return (
                  <button
                    key={app.id}
                    onClick={() => triggerAppLaunchWithFlight(app.id)}
                    className="flex flex-col items-center gap-1 active:scale-90 transition-transform group"
                  >
                    <div
                      className={`w-12 h-12 rounded-2xl ${app.color} flex items-center justify-center text-white shadow-lg ${app.ring} group-hover:scale-105 transition-transform`}
                    >
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-medium text-white/90 truncate max-w-[56px]">
                      {app.title}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Dock Bar with Favorites + Settings & Flashlight */}
            <div className="p-1.5 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/15 flex items-center justify-around my-1 shadow-xl">
              <button
                onClick={() => triggerAppLaunchWithFlight('phone')}
                className="w-10 h-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md active:scale-90 transition-transform"
                title="الهاتف"
              >
                <Phone className="w-4 h-4" />
              </button>

              <button
                onClick={() => triggerAppLaunchWithFlight('messages')}
                className="w-10 h-10 rounded-2xl bg-cyan-500 text-white flex items-center justify-center shadow-md active:scale-90 transition-transform"
                title="الرسائل"
              >
                <MessageSquare className="w-4 h-4" />
              </button>

              <button
                onClick={() => triggerAppLaunchWithFlight('camera')}
                className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center shadow-md active:scale-90 transition-transform"
                title="الكاميرا"
              >
                <Camera className="w-4 h-4" />
              </button>

              <button
                onClick={onToggleFlashlight}
                className={`w-10 h-10 rounded-2xl flex items-center justify-center shadow-md active:scale-90 transition-transform ${
                  flashlightOn
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'bg-white/15 text-white hover:bg-white/25'
                }`}
                title="المصباح"
              >
                <Flashlight className="w-4 h-4" />
              </button>

              <button
                onClick={() => triggerAppLaunchWithFlight('settings')}
                className="w-10 h-10 rounded-2xl bg-slate-700 text-white flex items-center justify-center shadow-md active:scale-90 transition-transform"
                title="الإعدادات والصلاحيات"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* BOTTOM VOICE CONTROLLER & ANDROID 3-BUTTON NAVIGATION */}
        <div className="relative z-30 px-4 pt-1 pb-2 bg-linear-to-t from-black/85 via-black/50 to-transparent flex flex-col items-center">
          {/* Keyboard input drawer toggle */}
          {showKeyboardInput ? (
            <form
              onSubmit={handleTextSubmit}
              className="w-full flex gap-2 items-center bg-slate-900/95 backdrop-blur-md p-1.5 rounded-2xl border border-white/20 mb-2 shadow-xl"
            >
              <input
                type="text"
                value={typedCommand}
                onChange={(e) => setTypedCommand(e.target.value)}
                placeholder={`اكتب أمراً لـ ${currentProfile.name}...`}
                autoFocus
                className="flex-1 px-3 py-1.5 text-xs text-white placeholder-slate-400 bg-transparent outline-hidden"
              />
              <button
                type="submit"
                className="p-2 rounded-xl bg-cyan-600 text-white hover:bg-cyan-500 active:scale-95"
              >
                <Send className="w-3.5 h-3.5 rotate-180" />
              </button>
              <button
                type="button"
                onClick={() => setShowKeyboardInput(false)}
                className="text-xs text-slate-400 px-1 hover:text-white"
              >
                ✕
              </button>
            </form>
          ) : (
            <div className="w-full flex items-center justify-between mb-1.5 px-2">
              <button
                onClick={() => setShowKeyboardInput(true)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/80 active:scale-90 transition-transform"
                title="الكتابة بالأحرف"
              >
                <Keyboard className="w-4 h-4" />
              </button>

              {/* Main Glowing Voice Listening Trigger Button */}
              <button
                onClick={onToggleListening}
                className={`relative px-5 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-xl active:scale-95 transition-all ${
                  isListening
                    ? 'bg-linear-to-r from-rose-500 to-amber-500 text-white ring-4 ring-rose-400/40 animate-pulse'
                    : 'bg-linear-to-r from-cyan-500 to-blue-600 text-white hover:brightness-110 shadow-cyan-500/25'
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-4 h-4 animate-bounce" />
                    <span>جارٍ الاستماع...</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    <span>تحدث مع «{currentProfile.name}»</span>
                  </>
                )}
              </button>

              <button
                onClick={() => onOpenApp('android_service')}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-emerald-300 active:scale-90 transition-transform"
                title="خدمات أندرويد وإمكانية الوصول"
              >
                <Smartphone className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* ANDROID 3-BUTTON SYSTEM NAVIGATION BAR */}
          <div className="w-full max-w-[240px] flex items-center justify-between py-1 px-4 text-white/60">
            {/* Back Button */}
            <button
              onClick={onCloseApp}
              className="p-1 hover:text-white active:scale-80 transition-transform"
              title="رجوع للخلف"
            >
              <Triangle className="w-3.5 h-3.5 -rotate-90 fill-current" />
            </button>

            {/* Home Button */}
            <button
              onClick={onCloseApp}
              className="p-1 hover:text-white active:scale-80 transition-transform"
              title="الشاشة الرئيسية"
            >
              <Circle className="w-3.5 h-3.5 fill-current" />
            </button>

            {/* Recent Apps Button */}
            <button
              onClick={() => onOpenApp('android_service')}
              className="p-1 hover:text-white active:scale-80 transition-transform"
              title="التطبيقات المفتوحة وخدمات أندرويد"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
